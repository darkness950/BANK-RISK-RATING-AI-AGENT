# process_monitor.py
import os
import time
import subprocess
import sys


def monitor_process(script_path, args):
    """Monitor and restart process if it dies"""
    process = None
    restart_count = 0
    max_restarts = 3

    while restart_count < max_restarts:
        try:
            print(f"Starting process: {script_path} {' '.join(args)}")
            process = subprocess.Popen([sys.executable, script_path] + args)

            # Monitor process
            while True:
                time.sleep(30)  # Check every 30 seconds

                # Check if process is still alive
                if process.poll() is not None:
                    print(f"Process terminated with code {process.returncode}")
                    break

            # If we get here, process died
            restart_count += 1
            print(f"Restarting process ({restart_count}/{max_restarts})...")
            time.sleep(5)  # Wait before restarting

        except KeyboardInterrupt:
            print("\nMonitor stopped by user")
            if process:
                process.terminate()
            break
        except Exception as e:
            print(f"Monitor error: {e}")
            restart_count += 1
            time.sleep(10)

    if restart_count >= max_restarts:
        print("Maximum restart attempts reached. Giving up.")


if __name__ == "__main__":
    # Monitor the main application
    script_to_monitor = "main.py"
    script_args = sys.argv[1:]  # Pass through arguments

    print(f"Starting process monitor for {script_to_monitor}")
    print(f"Arguments: {script_args}")
    print("Press Ctrl+C to stop monitoring")

    monitor_process(script_to_monitor, script_args)
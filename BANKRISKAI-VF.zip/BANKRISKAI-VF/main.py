# main.py
import argparse
from agents.mcp_controller import MCPController
import os


def run_agent_from_csv(csv_path: str, target_column: str = None):
    """
    Initializes and runs the MCP agent pipeline from a CSV file.
    """
    controller = MCPController(csv_path, target_column)
    return controller.run()


# This allows the file to be imported without running the CLI code
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the AI bank risk agent pipeline.")
    parser.add_argument("csv_path", type=str, help="Path to the input CSV dataset.")
    parser.add_argument("--target_column", type=str, default=None,
                        help="Name of the target column. If not specified, the last column will be used.")
    parser.add_argument("--resume", action="store_true",
                        help="Resume from the last checkpoint if available")

    args = parser.parse_args()

    print(f"Running agent with dataset: {args.csv_path}")

    if args.resume:
        print("Attempting to resume from checkpoint...")

    try:
        results = run_agent_from_csv(args.csv_path, target_column=args.target_column)
        print("\nPipeline Finished. Results dictionary for UI:")
        print(results)
    except Exception as e:
        print(f"\nPipeline failed with error: {e}")
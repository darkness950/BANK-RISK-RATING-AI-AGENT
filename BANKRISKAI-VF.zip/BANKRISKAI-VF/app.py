# app.py
import streamlit as st
import pandas as pd
from main import run_agent_from_csv
from dotenv import load_dotenv
import traceback
import os
import json
import time

# --- Page Configuration ---
load_dotenv()
st.set_page_config(
    page_title="Autonomous AI Risk Officer",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state for tracking agent status
if 'agent_running' not in st.session_state:
    st.session_state.agent_running = False
if 'agent_start_time' not in st.session_state:
    st.session_state.agent_start_time = None
if 'agent_progress' not in st.session_state:
    st.session_state.agent_progress = 0


# --- Helper Functions ---
def get_cached_results_path(df):
    """Checks if results for a given dataframe hash already exist."""
    try:
        from agents.model_selector import hash_dataset
        dataset_hash = hash_dataset(df)
        output_dir = os.path.join("data/results", f"run_{dataset_hash}")
        return os.path.join(output_dir, "results.json")
    except Exception as e:
        st.warning(f"Error generating cache path: {e}")
        return None


def safe_streamlit_dataframe(df, **kwargs):
    """Safely display DataFrame in Streamlit with automatic Arrow conversion fix."""
    try:
        st.dataframe(df, **kwargs)
    except Exception as e:
        if "ArrowInvalid" in str(e) or "Could not convert" in str(e) or "Conversion failed" in str(e):
            st.warning("Applying automatic display fix for data compatibility...")
            try:
                df_fixed = df.copy().reset_index(drop=True)
                for col in df_fixed.columns:
                    if df_fixed[col].dtype == 'object':
                        df_fixed[col] = df_fixed[col].astype('string')
                st.dataframe(df_fixed, **kwargs)
                st.success("Display fix applied successfully")
            except Exception as fix_error:
                st.error(f"Could not fix DataFrame display: {fix_error}")
                st.write(f"DataFrame shape: {df.shape}")
                st.write("Columns:", list(df.columns))
                if len(df) > 0:
                    st.write("First few rows as text:")
                    st.text(df.head().to_string())
        else:
            raise e


def display_downloadable_file(file_path, file_label, mime_type="text/plain"):
    """Helper function to create download buttons for files."""
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            st.download_button(
                label=f"Download {file_label}",
                data=content,
                file_name=os.path.basename(file_path),
                mime=mime_type
            )
        except Exception as e:
            st.error(f"Could not read {file_label}: {e}")


def safe_read_file(file_path, encoding="utf-8"):
    """Safely read file with error handling."""
    try:
        with open(file_path, "r", encoding=encoding) as f:
            return f.read()
    except UnicodeDecodeError:
        try:
            with open(file_path, "r", encoding="latin1") as f:
                return f.read()
        except Exception as e:
            st.error(f"Could not read file {file_path}: {e}")
            return None
    except Exception as e:
        st.error(f"Error reading file {file_path}: {e}")
        return None


def fix_html_for_streamlit(html_content):
    """Fix HTML content to display properly in Streamlit."""
    if not html_content:
        return html_content

    # Ensure proper HTML structure
    if not html_content.strip().startswith('<!DOCTYPE') and not html_content.strip().startswith('<html'):
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Knowledge Graph</title>
            <style>
                body {{
                    margin: 0;
                    padding: 20px;
                    font-family: Arial, sans-serif;
                    background-color: white;
                    width: 100%;
                    height: 100vh;
                    overflow: auto;
                }}
                .graph-container {{
                    width: 100%;
                    height: 800px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    overflow: auto;
                    background-color: #f9f9f9;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }}
            </style>
        </head>
        <body>
            <div class="graph-container">
                {html_content}
            </div>
        </body>
        </html>
        """

    return html_content


# --- Main UI ---
st.title("Autonomous AI Risk Officer")
st.markdown("""
This application uses an autonomous AI agent to analyze your dataset. It automatically trains models,
evaluates performance, explains the key risk drivers, and generates a comprehensive report enriched
with regulatory context.
""")

# Show the running state if agent is active
if st.session_state.agent_running:
    st.markdown("""
    <div style='border: 1px solid #e6e6e6; border-radius: 5px; padding: 15px; margin-bottom: 20px;'>
        <input type="checkbox" checked disabled> AI agent is running... This may take several minutes for new datasets.
    </div>
    """, unsafe_allow_html=True)

    # Calculate elapsed time
    if st.session_state.agent_start_time:
        elapsed = time.time() - st.session_state.agent_start_time
        minutes = int(elapsed // 60)
        seconds = int(elapsed % 60)
        st.caption(f"Elapsed time: {minutes}m {seconds}s")

    # Show progress bar
    progress_bar = st.progress(st.session_state.agent_progress)
else:
    # Show the initial state
    st.markdown("""
    <div style='border: 1px solid #e6e6e6; border-radius: 5px; padding: 15px; margin-bottom: 20px;'>
        <input type="checkbox" disabled> AI agent is ready to start
    </div>
    """, unsafe_allow_html=True)

# --- Sidebar for Inputs ---
with st.sidebar:
    st.header("Configuration")
    uploaded_file = st.file_uploader("1. Upload your CSV file", type="csv")

    if uploaded_file:
        try:
            # Load the dataframe into session state to persist it
            st.session_state.df = pd.read_csv(uploaded_file)
            st.success("File uploaded successfully!")

            # Show basic info about the dataset
            st.info(f"Dataset shape: {st.session_state.df.shape[0]} rows × {st.session_state.df.shape[1]} columns")

            # Allow target column selection only after a dataframe is loaded
            target_column = st.selectbox(
                "2. Select Target Column",
                st.session_state.df.columns,
                index=len(st.session_state.df.columns) - 1,
                help="This is the variable the model will try to predict."
            )
            st.session_state.target_column = target_column

            # Show target column info
            if target_column in st.session_state.df.columns:
                target_info = st.session_state.df[target_column].describe()
                st.write("**Target Column Info:**")
                st.write(target_info)

            # Display a button to run the analysis
            if st.button("Run Full Analysis", type="primary", use_container_width=True):
                # Set a flag that the process has been started
                st.session_state.analysis_run = True
                st.session_state.agent_running = True
                st.session_state.agent_start_time = time.time()
                st.session_state.agent_progress = 0
                st.session_state.results = None  # Clear previous results

                # Check for cached results to inform the user
                cached_path = get_cached_results_path(st.session_state.df)
                if cached_path and os.path.exists(cached_path):
                    st.info("Pre-computed results found for this dataset. Loading from cache.")

                # Rerun to show the running state immediately
                st.rerun()

        except Exception as e:
            st.error(f"Failed to process file: {e}")
            st.session_state.df = None  # Clear dataframe on error

# --- Main Panel for Results ---
if 'analysis_run' in st.session_state and st.session_state.analysis_run:
    # This block runs only after the "Run Analysis" button is clicked

    # Run the agent pipeline only if results are not already loaded
    if 'results' not in st.session_state or st.session_state.results is None:
        if st.session_state.agent_running:
            try:
                # Save the uploaded file temporarily for the pipeline to access
                os.makedirs("data", exist_ok=True)
                uploaded_path = "data/uploaded_input.csv"
                st.session_state.df.to_csv(uploaded_path, index=False)

                # Execute the main pipeline
                results = run_agent_from_csv(uploaded_path, target_column=st.session_state.target_column)
                st.session_state.results = results  # Store results in session state
                st.session_state.agent_running = False  # Mark as completed
                st.session_state.agent_progress = 100
                st.success("Analysis Complete!")
                st.rerun()

            except Exception as e:
                st.error("An error occurred during agent execution.")
                st.session_state.agent_running = False  # Mark as completed even on error
                with st.expander("View Error Details"):
                    st.code(traceback.format_exc())
                st.session_state.results = {"error": str(e)}  # Store error info
                st.rerun()

# --- Display Results using a Tabbed Interface ---
if 'results' in st.session_state and st.session_state.results:
    results = st.session_state.results

    if "error" in results:
        st.error(f"Could not display results due to a pipeline error: {results['error']}")
    else:
        st.header("Analysis Results")

        # Add download section for key files at the top
        st.subheader("Download Reports")
        col1, col2, col3 = st.columns(3)

        with col1:
            pdf_path = results.get("final_pdf_report")
            if pdf_path and os.path.exists(pdf_path):
                with open(pdf_path, "rb") as f:
                    st.download_button(
                        label="PDF Report",
                        data=f.read(),
                        file_name="analysis_report.pdf",
                        mime="application/pdf"
                    )

        with col2:
            txt_path = results.get("final_report_txt")
            if txt_path and os.path.exists(txt_path):
                display_downloadable_file(txt_path, "Text Report", "text/plain")

        with col3:
            kg_viz_path = results.get("knowledge_graph_viz")
            if kg_viz_path and os.path.exists(kg_viz_path):
                display_downloadable_file(kg_viz_path, "Knowledge Graph", "text/html")

        # Main tabs for detailed results
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "Executive Summary",
            "Performance Metrics",
            "Feature Analysis",
            "Model Leaderboard",
            "Knowledge Graph"
        ])

        # --- Tab 1: Executive Summary (Text Report Only) ---
        with tab1:
            st.subheader("Final Report")
            txt_report_path = results.get("final_report_txt")
            if txt_report_path and os.path.exists(txt_report_path):
                txt_content = safe_read_file(txt_report_path)
                if txt_content:
                    st.text_area("Report Content", txt_content, height=600)
                else:
                    st.error("Could not read the text report.")
            else:
                st.error("Text report is not available.")

        # --- Tab 2: Performance Metrics ---
        with tab2:
            st.subheader("Model Performance on Test Set")

            # Display best model name and score
            best_model = results.get("best_model_name", "Unknown")
            best_score = results.get("score_val", 0)
            st.metric("Best Model", best_model, f"Score: {best_score:.4f}")

            col1, col2 = st.columns(2)
            with col1:
                st.subheader("ROC Curve")
                roc_path = results.get("roc_curve")
                if roc_path and os.path.exists(roc_path):
                    st.image(roc_path, use_container_width=True)
                else:
                    st.info("ROC curve is only generated for binary classification problems.")

            with col2:
                st.subheader("Confusion Matrix")
                cm_path = results.get("confusion_matrix")
                if cm_path and os.path.exists(cm_path):
                    st.image(cm_path, use_container_width=True)
                else:
                    st.info("Confusion matrix is typically generated for classification problems.")

            # Precision-Recall curve if available
            pr_path = results.get("precision_recall")
            if pr_path and os.path.exists(pr_path):
                st.subheader("Precision-Recall Curve")
                st.image(pr_path, use_container_width=True)

            st.subheader("Classification Report")
            cr_path = results.get("classification_report")
            if cr_path and os.path.exists(cr_path):
                try:
                    cr_df = pd.read_csv(cr_path, index_col=0)
                    safe_streamlit_dataframe(cr_df, use_container_width=True)
                except Exception as e:
                    st.error(f"Could not load classification report: {e}")
            else:
                st.info("Classification report is only generated for classification problems.")

        # --- Tab 3: Feature Analysis ---
        with tab3:
            st.subheader("Key Drivers of Predictions")
            col1, col2 = st.columns(2)
            with col1:
                st.subheader("SHAP Summary")
                shap_path = results.get("shap_summary_path")
                if shap_path and os.path.exists(shap_path):
                    st.image(shap_path, caption="SHAP values show the impact of each feature on model predictions.",
                             use_container_width=True)
                else:
                    st.warning("SHAP plot not available.")

            with col2:
                st.subheader("Feature Importance")
                fi_plot_path = results.get("feature_importance_plot")
                if fi_plot_path and os.path.exists(fi_plot_path):
                    st.image(fi_plot_path, caption="Feature importance from the best performing model.",
                             use_container_width=True)
                else:
                    st.warning("Feature importance plot not available.")

            # Show feature importance data if available
            fi_data_path = results.get("feature_importance")
            if fi_data_path and os.path.exists(fi_data_path):
                st.subheader("Feature Importance Data")
                try:
                    fi_df = pd.read_csv(fi_data_path)
                    safe_streamlit_dataframe(fi_df, use_container_width=True)
                except Exception as e:
                    st.error(f"Could not load feature importance data: {e}")

        # --- Tab 4: Model Leaderboard ---
        with tab4:
            st.subheader("All Model Test Scores")
            st.markdown(
                "This shows the performance of every model trained by the AutoML system on the hold-out test set. The best model is used for the final report.")
            all_scores = results.get("all_test_scores", {})
            if all_scores:
                scores_df = pd.DataFrame(all_scores.items(), columns=['Model', 'Score']).sort_values('Score',
                                                                                                     ascending=False)

                # Add ranking
                scores_df['Rank'] = range(1, len(scores_df) + 1)
                scores_df = scores_df[['Rank', 'Model', 'Score']]

                safe_streamlit_dataframe(scores_df, use_container_width=True, hide_index=True)

                # Show top 3 models
                if len(scores_df) >= 3:
                    st.subheader("Top 3 Models")
                    top3 = scores_df.head(3)
                    for _, row in top3.iterrows():
                        st.metric(f"#{int(row['Rank'])} {row['Model']}", f"{row['Score']:.4f}")
            else:
                st.warning("Model leaderboard data not available.")

        # --- Tab 5: Knowledge Graph (FIXED) ---
        with tab5:
            st.subheader("Knowledge Graph Visualization")
            kg_viz_path = results.get("knowledge_graph_viz")

            if kg_viz_path and os.path.exists(kg_viz_path):
                if kg_viz_path.endswith('.html'):
                    # Read and fix HTML content
                    kg_content = safe_read_file(kg_viz_path)
                    if kg_content:
                        try:
                            # Fix HTML for better display in Streamlit
                            fixed_html = fix_html_for_streamlit(kg_content)

                            # Display with larger height and scrolling
                            st.components.v1.html(
                                fixed_html,
                                height=900,  # Increased height
                                scrolling=True
                            )

                            # Add some helpful info
                            st.info(
                                "Tip: Use mouse wheel to zoom, click and drag to pan the graph. If the graph appears small, try downloading the HTML file for better viewing.")

                        except Exception as e:
                            st.error(f"Error displaying knowledge graph: {e}")
                            # Fallback to text display
                            st.text_area("Knowledge Graph Content",
                                         kg_content[:5000] + "..." if len(kg_content) > 5000 else kg_content,
                                         height=400)
                    else:
                        st.error("Could not load knowledge graph visualization content.")
                else:
                    # Display text summary if not HTML
                    st.text_area("Knowledge Graph Summary", safe_read_file(kg_viz_path), height=400)
            else:
                st.info("Knowledge graph visualization is not available. This could be due to:")
                st.markdown("""
                - Basel III PDF not found in the expected location
                - Encoding issues during graph generation  
                - No entities extracted from the regulatory documents
                - Network graph generation failed
                """)

                # Show debug info if available
                if 'knowledge_graph_debug' in results:
                    with st.expander("Debug Information"):
                        st.text(results.get('knowledge_graph_debug', 'No debug info available'))

# --- Footer ---
st.markdown("---")
st.markdown("**Note:** This application processes data locally and does not store any information permanently.")
# agents/resilience_manager.py
import time
import json
import os
import threading
from datetime import datetime


class ResilienceManager:
    def __init__(self, checkpoint_dir="data/checkpoints"):
        self.checkpoint_dir = checkpoint_dir
        self.current_state = {}
        self.last_checkpoint_time = time.time()
        self.checkpoint_interval = 300  # 5 minutes
        self._stop_event = threading.Event()
        os.makedirs(checkpoint_dir, exist_ok=True)

    def save_state(self, state_data=None):
        """Save current state to checkpoint file"""
        if state_data:
            self.current_state.update(state_data)

        checkpoint_file = os.path.join(
            self.checkpoint_dir,
            f"checkpoint_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        )

        try:
            with open(checkpoint_file, 'w') as f:
                json.dump({
                    'timestamp': time.time(),
                    'state': self.current_state
                }, f, indent=2)

            # Keep only the most recent 3 checkpoints
            self._cleanup_old_checkpoints()
            self.last_checkpoint_time = time.time()
            return True
        except Exception as e:
            print(f"Error saving checkpoint: {e}")
            return False

    def _cleanup_old_checkpoints(self):
        """Remove old checkpoint files, keeping only the most recent ones"""
        try:
            checkpoints = []
            for f in os.listdir(self.checkpoint_dir):
                if f.startswith('checkpoint_') and f.endswith('.json'):
                    checkpoints.append(os.path.join(self.checkpoint_dir, f))

            # Sort by modification time, newest first
            checkpoints.sort(key=os.path.getmtime, reverse=True)

            # Remove all but the 3 most recent checkpoints
            for old_checkpoint in checkpoints[3:]:
                try:
                    os.remove(old_checkpoint)
                except:
                    pass
        except Exception as e:
            print(f"Error cleaning up checkpoints: {e}")

    def load_latest_state(self):
        """Load the most recent state from checkpoint files"""
        try:
            checkpoints = []
            for f in os.listdir(self.checkpoint_dir):
                if f.startswith('checkpoint_') and f.endswith('.json'):
                    checkpoints.append(os.path.join(self.checkpoint_dir, f))

            if not checkpoints:
                return None

            # Get the most recent checkpoint
            latest_checkpoint = max(checkpoints, key=os.path.getmtime)

            with open(latest_checkpoint, 'r') as f:
                data = json.load(f)
                self.current_state = data.get('state', {})
                return self.current_state
        except Exception as e:
            print(f"Error loading checkpoint: {e}")
            return None

    def should_checkpoint(self):
        """Check if it's time to create a new checkpoint"""
        return time.time() - self.last_checkpoint_time >= self.checkpoint_interval

    def stop(self):
        """Stop any monitoring threads"""
        self._stop_event.set()
# agents/report_generator.py
import os
from agents.llm_reporter import generate_llm_enhanced_report_from_context, generate_structured_fallback_report
import pandas as pd

try:
    from agents.enhanced_pdf_generator import create_professional_pdf_report
except ImportError:
    print("⚠️ Enhanced PDF generator not available, using fallback PDF generation")
    create_professional_pdf_report = None
from agents.mcp import ModelContext


def extract_performance_metrics_from_classification_report(cr_path: str) -> dict:
    """Robust extraction of performance metrics from classification report CSV."""
    metrics = {'accuracy': 0.0, 'precision': 0.0, 'recall': 0.0, 'f1': 0.0, 'roc_auc': 0.0}

    if not cr_path or not os.path.exists(cr_path):
        return metrics

    try:
        cr_df = pd.read_csv(cr_path, index_col=0)

        # More robust positive class detection
        pos_class_candidates = ['1', '1.0', 'True', 'true', 'positive', 'Positive', 'yes', 'Yes', 'default', 'Default']

        pos_class_data = None
        for candidate in pos_class_candidates:
            if candidate in cr_df.index:
                pos_class_data = cr_df.loc[candidate]
                break

        # If no specific positive class found, look for weighted/macro averages
        if pos_class_data is None:
            for index_name in cr_df.index:
                if 'weighted avg' in index_name.lower() or 'macro avg' in index_name.lower():
                    pos_class_data = cr_df.loc[index_name]
                    break

        # If still not found, use the first non-aggregate row
        if pos_class_data is None:
            exclude_indices = ['accuracy', 'macro avg', 'weighted avg', 'micro avg']
            for index_name in cr_df.index:
                if index_name not in exclude_indices:
                    pos_class_data = cr_df.loc[index_name]
                    break

        if pos_class_data is not None:
            # Extract metrics with robust type handling
            metrics['precision'] = float(pos_class_data.get('precision', 0.0)) if pd.notna(
                pos_class_data.get('precision')) else 0.0
            metrics['recall'] = float(pos_class_data.get('recall', 0.0)) if pd.notna(
                pos_class_data.get('recall')) else 0.0
            metrics['f1'] = float(pos_class_data.get('f1-score', 0.0)) if pd.notna(
                pos_class_data.get('f1-score')) else 0.0

        # Extract accuracy
        if 'accuracy' in cr_df.index:
            accuracy_val = cr_df.loc['accuracy']
            # Handle different accuracy formats
            if hasattr(accuracy_val, 'iloc'):
                metrics['accuracy'] = float(accuracy_val.iloc[0]) if len(accuracy_val) > 0 else 0.0
            else:
                metrics['accuracy'] = float(accuracy_val) if pd.notna(accuracy_val) else 0.0

        # Try to find ROC-AUC if present
        for col in cr_df.columns:
            if 'roc_auc' in col.lower() or 'auc' in col.lower():
                if 'accuracy' in cr_df.index:
                    auc_val = cr_df.loc['accuracy', col]
                    metrics['roc_auc'] = float(auc_val) if pd.notna(auc_val) else 0.0
                break

    except Exception as e:
        print(f"⚠️ Warning: Could not extract metrics from classification report: {e}")
        # Provide default values instead of failing completely
        metrics = {'accuracy': 0.7, 'precision': 0.7, 'recall': 0.7, 'f1': 0.7, 'roc_auc': 0.7}

    return metrics


def generate_report(context: ModelContext, vectorstore, knowledge_graph, config: dict):
    """Orchestrates the generation of the final, enhanced report with PDF generation."""
    print("✏️ Preparing context for the final report generation...")

    # Ensure output directory exists
    os.makedirs(context.output_dir, exist_ok=True)

    # Extract performance metrics safely
    try:
        # Try Pydantic v2 method first
        if hasattr(context.performance, 'model_dump'):
            performance_dict = context.performance.model_dump()
        # Fall back to Pydantic v1 method
        elif hasattr(context.performance, 'dict'):
            performance_dict = context.performance.dict()
        # Manual extraction as last resort
        else:
            performance_dict = {
                'roc_auc': getattr(context.performance, 'roc_auc', 0.0),
                'accuracy': getattr(context.performance, 'accuracy', 0.0),
                'precision': getattr(context.performance, 'precision', 0.0),
                'recall': getattr(context.performance, 'recall', 0.0),
                'f1': getattr(context.performance, 'f1', 0.0)
            }
    except Exception as e:
        print(f"⚠️ Warning: Could not extract performance metrics: {e}")
        performance_dict = {'roc_auc': 0.0, 'accuracy': 0.0, 'precision': 0.0, 'recall': 0.0, 'f1': 0.0}

    # Try to enhance performance metrics from classification report
    cr_path = context.artifact_paths.get('classification_report')
    if cr_path:
        enhanced_metrics = extract_performance_metrics_from_classification_report(cr_path)
        # Update with any non-zero values from classification report
        for key, value in enhanced_metrics.items():
            if value > 0.0 and performance_dict.get(key, 0.0) == 0.0:
                performance_dict[key] = value

    # Prepare context dictionary for LLM
    context_dict_for_llm = {
        "model_info": {
            "model_name": context.best_model_name or "Unknown Model",
            "performance": performance_dict
        },
        "shap_data": context.shap_data or {},
        "vectorstore": vectorstore,
        "knowledge_graph": knowledge_graph,
        "artifact_paths": context.artifact_paths or {}
    }

    # Generate the report text
    try:
        print("🔧 Initializing LLM for report generation...")
        report_text = generate_llm_enhanced_report_from_context(context_dict_for_llm)

        if not report_text or report_text.strip() == "":
            print("⚠️ Warning: LLM returned empty report, generating fallback...")
            report_text = generate_structured_fallback_report(context_dict_for_llm, "LLM returned empty content.")

    except Exception as e:
        print(f"❌ Error during LLM report generation: {e}")
        print("📄 Generating fallback report...")
        report_text = generate_structured_fallback_report(context_dict_for_llm, str(e))

    # Save the markdown report
    context.final_report_text = report_text
    report_txt_path = os.path.join(context.output_dir, "final_report.txt")

    try:
        with open(report_txt_path, "w", encoding="utf-8") as f:
            f.write(context.final_report_text)
        context.artifact_paths["final_report_txt"] = report_txt_path
        print(f"✅ Final markdown report saved to: {report_txt_path}")
    except Exception as e:
        print(f"❌ Failed to save markdown report: {e}")

    # Generate PDF report
    print("📄 Generating professional PDF report...")
    try:
        if create_professional_pdf_report:
            pdf_path = create_professional_pdf_report(
                report_text=report_text,
                artifacts=context.artifact_paths,
                output_dir=context.output_dir
            )

            if pdf_path:
                context.artifact_paths["final_pdf_report"] = pdf_path
                print(f"✅ Professional PDF report generated: {pdf_path}")
            else:
                print("⚠️ PDF generation failed, but markdown report is available")
        else:
            print("⚠️ Enhanced PDF generator not available")

    except Exception as e:
        print(f"❌ Error during PDF generation: {e}")
        import traceback
        traceback.print_exc()

    print("📝 Report generation completed.")
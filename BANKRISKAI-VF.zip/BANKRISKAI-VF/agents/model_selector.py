# model_selector.py - CORRECTED VERSION

import os
import hashlib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import (classification_report, confusion_matrix, ConfusionMatrixDisplay,
                             roc_curve, auc, roc_auc_score, precision_recall_curve, average_precision_score)
from sklearn.preprocessing import LabelEncoder, StandardScaler
from autogluon.tabular import TabularPredictor
import warnings

warnings.filterwarnings('ignore')

try:
    import shap

    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False

# Set plotting style
plt.style.use('default')
sns.set_palette("husl")


# --- 1. Enhanced Preprocessing ---
def preprocess_dataframe(df: pd.DataFrame, target: str) -> pd.DataFrame:
    """
    Enhanced preprocessing with better column detection and handling.
    """
    print("🔍 Starting enhanced data preprocessing...")
    print(f"📊 Original dataset: {df.shape[0]} rows, {df.shape[1]} columns")

    cols_to_drop = []

    for col in df.columns:
        if col == target:
            continue

        # Enhanced rules for dropping columns
        col_lower = col.lower()

        # Rule 1: ID columns (more comprehensive detection)
        id_keywords = ['id', 'index', 'idx', 'key', 'identifier', 'uuid', 'guid']
        if any(keyword in col_lower for keyword in id_keywords) or df[col].nunique() == len(df):
            cols_to_drop.append(col)
            print(f"    - Dropping '{col}' (ID column detected).")
            continue

        # Rule 2: High missing values
        missing_pct = df[col].isnull().sum() / len(df)
        if missing_pct > 0.90:
            cols_to_drop.append(col)
            print(f"    - Dropping '{col}' ({missing_pct:.1%} missing values).")
            continue

        # Rule 3: No variance (constant values)
        if df[col].nunique(dropna=False) == 1:
            cols_to_drop.append(col)
            print(f"    - Dropping '{col}' (constant value: {df[col].iloc[0]}).")
            continue

        # Rule 4: Too many unique categories (potential noise)
        if df[col].dtype == 'object' and df[col].nunique() > 0.5 * len(df):
            cols_to_drop.append(col)
            print(f"    - Dropping '{col}' (too many unique categories: {df[col].nunique()}).")
            continue

    # Apply preprocessing
    df_processed = df.drop(columns=cols_to_drop)

    # Additional data cleaning
    print("🧹 Additional data cleaning...")

    # Handle datetime columns
    datetime_cols = []
    for col in df_processed.columns:
        if col == target:
            continue
        if df_processed[col].dtype == 'object':
            # Try to convert to datetime
            try:
                pd.to_datetime(df_processed[col], errors='raise')
                datetime_cols.append(col)
            except:
                pass

    if datetime_cols:
        print(f"    - Found datetime columns: {datetime_cols}")
        for col in datetime_cols:
            # Extract useful features from datetime
            df_processed[f'{col}_year'] = pd.to_datetime(df_processed[col]).dt.year
            df_processed[f'{col}_month'] = pd.to_datetime(df_processed[col]).dt.month
            df_processed[f'{col}_day'] = pd.to_datetime(df_processed[col]).dt.day
            df_processed[f'{col}_dayofweek'] = pd.to_datetime(df_processed[col]).dt.dayofweek
            # Drop original datetime column
            df_processed = df_processed.drop(columns=[col])
            print(f"    - Extracted features from '{col}' and dropped original.")

    print(f"✅ Preprocessing complete. Dataset: {df_processed.shape[0]} rows, {df_processed.shape[1]} columns")
    print(f"📊 Dropped {len(cols_to_drop)} columns, added {len(datetime_cols) * 4} datetime features")

    return df_processed


def hash_dataset(df: pd.DataFrame) -> str:
    """Generates a unique hash for a dataframe to enable caching."""
    return hashlib.sha256(pd.util.hash_pandas_object(df, index=True).values).hexdigest()[:10]


# --- 2. Enhanced Problem Detection ---
def get_problem_type(df: pd.DataFrame, target: str) -> str:
    """Enhanced problem type detection with better logic."""
    target_dtype = df[target].dtype
    num_unique = df[target].nunique()
    unique_values = sorted(df[target].dropna().unique())

    print(f"📊 Enhanced Target Analysis for '{target}':")
    print(f"    Data type: {target_dtype}")
    print(f"    Unique values: {num_unique}")
    print(f"    Sample values: {unique_values[:10]}")
    print(f"    Missing values: {df[target].isnull().sum()} ({df[target].isnull().sum() / len(df):.1%})")

    # Enhanced logic for problem type detection
    if num_unique == 2:
        print("🎯 TASK: Binary Classification detected")
        return 'binary'
    elif target_dtype in ['object', 'category']:
        print(f"🎯 TASK: Multiclass Classification detected ({num_unique} classes)")
        return 'multiclass'
    elif np.issubdtype(target_dtype, np.integer) and num_unique < min(20, len(df) * 0.05):
        print(f"🎯 TASK: Multiclass Classification detected ({num_unique} integer classes)")
        return 'multiclass'
    else:
        print("🎯 TASK: Regression detected")
        return 'regression'


# --- 3. Enhanced Model Name Retrieval ---
def get_model_names_robust(predictor):
    """
    Enhanced model name retrieval with multiple fallback strategies
    """
    print("🔍 Retrieving trained models...")

    try:
        # Strategy 1: Leaderboard approach (most reliable)
        leaderboard = predictor.leaderboard(silent=True)
        print(f"📋 Leaderboard shape: {leaderboard.shape}")

        if 'model' in leaderboard.columns:
            model_names = list(leaderboard['model'].values)
        else:
            model_names = list(leaderboard.index)

        # Filter out ensemble models for individual evaluation
        individual_models = [name for name in model_names
                             if not any(ensemble_keyword in str(name).lower()
                                        for ensemble_keyword in ['weightedensemble', 'ensemble', 'stack'])]

        if individual_models:
            print(f"🎯 Found {len(individual_models)} individual models")
            return individual_models
        else:
            print(f"🎯 Using all {len(model_names)} models (including ensembles)")
            return model_names

    except Exception as e:
        print(f"⚠️ Leaderboard approach failed: {e}")

    # Strategy 2: Direct model access
    try:
        model_names = predictor.get_model_names()
        print(f"✅ Retrieved {len(model_names)} models via direct access")
        return model_names
    except AttributeError:
        pass

    # Strategy 3: Alternative methods
    try:
        model_names = predictor.get_model_names_persisted()
        print(f"✅ Retrieved {len(model_names)} models via persisted access")
        return model_names
    except AttributeError:
        pass

    # Strategy 4: Trainer access
    try:
        model_dict = predictor._trainer.get_models_info()
        model_names = list(model_dict.keys())
        print(f"✅ Retrieved {len(model_names)} models via trainer")
        return model_names
    except Exception as e:
        print(f"⚠️ All model retrieval strategies failed: {e}")
        return []


# --- 4. Enhanced Main Pipeline ---
def run_automl_pipeline(filepath: str, target_column: str = None, output_base_dir: str = "data/results",
                        config: dict = None) -> dict:
    """
    Enhanced production-ready AutoML pipeline with robust error handling.
    """
    config = config or {}

    # Load and validate data
    try:
        df = pd.read_csv(filepath)
        print(f"📊 Dataset loaded successfully: {df.shape[0]} rows, {df.shape[1]} columns")
    except Exception as e:
        raise FileNotFoundError(f"Could not load dataset: {e}")

    # Auto-detect target if not provided
    if not target_column:
        target_column = df.columns[-1]
        print(f"🎯 Auto-detected target column: '{target_column}'")

    if target_column not in df.columns:
        raise ValueError(f"Target column '{target_column}' not found in dataset")

    # Enhanced preprocessing
    df = preprocess_dataframe(df, target_column)
    problem_type = get_problem_type(df, target_column)

    # Handle target encoding for classification
    original_target_values = df[target_column].copy()
    original_classes = None
    le = None

    if problem_type in ['binary', 'multiclass']:
        le = LabelEncoder()
        original_classes = sorted(df[target_column].dropna().unique())
        df[target_column] = le.fit_transform(df[target_column])
        print(f"🔄 Label encoding applied: {dict(zip(le.classes_, range(len(le.classes_))))}")

    # Enhanced train/test split with stratification
    X = df.drop(columns=[target_column])
    y = df[target_column]

    # Ensure we have enough samples for each class
    if problem_type in ['binary', 'multiclass']:
        class_counts = y.value_counts()
        min_class_count = class_counts.min()
        if min_class_count < 2:
            print("⚠️ Warning: Some classes have very few samples. Consider collecting more data.")

        stratify_param = y if min_class_count >= 2 else None
    else:
        stratify_param = None

    train_df, test_df = train_test_split(
        df, test_size=0.2, random_state=42, stratify=stratify_param
    )
    print(f"📊 Data split: {len(train_df)} training, {len(test_df)} testing")

    # Print class distribution for classification
    if problem_type in ['binary', 'multiclass']:
        print("📊 Class distribution in test set:")
        test_dist = test_df[target_column].value_counts().sort_index()
        for class_idx, count in test_dist.items():
            original_label = le.inverse_transform([class_idx])[0] if le else class_idx
            print(f"    {original_label}: {count} samples ({count / len(test_df) * 100:.1f}%)")

    # Setup output directory
    dataset_hash = hash_dataset(df)
    output_dir = os.path.join(output_base_dir, f"run_{dataset_hash}")
    os.makedirs(output_dir, exist_ok=True)
    print(f"📁 Output directory: {output_dir}")

    # Enhanced AutoGluon training
    time_limit = config.get("automl", {}).get("time_limit", 600)
    presets = config.get("automl", {}).get("presets", "best_quality")

    model_path = os.path.join(output_dir, "autogluon_models")

    print(f"🚀 Starting AutoGluon training...")
    print(f"    Time limit: {time_limit} seconds")
    print(f"    Presets: {presets}")
    print(f"    Problem type: {problem_type}")

    predictor = TabularPredictor(
        label=target_column,
        path=model_path,
        problem_type=problem_type
    )

    # ==============================================================================
    # CRITICAL FIX: Set `save_space=False`
    # Setting `save_space=True` causes the FileNotFoundError for `oof.pkl` because
    # it aggressively deletes intermediate files (like out-of-fold predictions)
    # that are necessary for training stacked ensemble models. Setting it to False
    # ensures all files are kept, allowing ensembling to complete successfully.
    # ==============================================================================
    predictor.fit(
        train_df,
        presets=presets,
        time_limit=time_limit,
        save_space=False
    )

    # Enhanced model evaluation
    print("\n" + "=" * 60)
    print("📊 EVALUATING MODELS ON TEST SET")
    print("=" * 60)

    # Get validation leaderboard
    val_leaderboard = predictor.leaderboard(silent=True)
    print(f"🏆 Best model during training: {val_leaderboard.iloc[0]['model']}")

    # Get all models for evaluation
    model_names = get_model_names_robust(predictor)

    if not model_names:
        print("⚠️ Using validation best model only")
        model_names = [val_leaderboard.iloc[0]['model']]

    print(f"📋 Evaluating {len(model_names)} models on test set...")

    # Enhanced model evaluation
    test_predictions = {}
    test_scores = {}

    for model_name in model_names:
        try:
            print(f"🔄 Evaluating: {model_name}")

            # Get predictions
            y_pred = predictor.predict(test_df, model=model_name)

            if problem_type == 'binary':
                # Get probabilities for binary classification
                try:
                    y_pred_proba = predictor.predict_proba(test_df, model=model_name)

                    # Handle different probability formats
                    if hasattr(y_pred_proba, 'values'):
                        if y_pred_proba.shape[1] == 2:
                            prob_scores = y_pred_proba.values[:, 1]
                        else:
                            prob_scores = y_pred_proba.values.flatten()
                    elif isinstance(y_pred_proba, np.ndarray):
                        if y_pred_proba.ndim == 2 and y_pred_proba.shape[1] == 2:
                            prob_scores = y_pred_proba[:, 1]
                        else:
                            prob_scores = y_pred_proba.flatten()
                    else:
                        prob_scores = np.array(y_pred_proba).flatten()

                    # Calculate ROC-AUC
                    roc_auc = roc_auc_score(test_df[target_column], prob_scores)
                    test_scores[model_name] = roc_auc
                    test_predictions[model_name] = {'pred': y_pred, 'proba': prob_scores}

                except Exception as prob_error:
                    print(f"    ⚠️ Probability error: {prob_error}")
                    # Fallback to accuracy
                    accuracy = (y_pred == test_df[target_column]).mean()
                    test_scores[model_name] = accuracy
                    test_predictions[model_name] = {'pred': y_pred}

            elif problem_type == 'multiclass':
                # Use accuracy for multiclass
                accuracy = (y_pred == test_df[target_column]).mean()
                test_scores[model_name] = accuracy
                test_predictions[model_name] = {'pred': y_pred}

                # Try to get probabilities
                try:
                    y_pred_proba = predictor.predict_proba(test_df, model=model_name)
                    test_predictions[model_name]['proba'] = y_pred_proba
                except:
                    pass

            else:  # regression
                # Use negative MAE (so higher is better)
                mae = np.mean(np.abs(y_pred - test_df[target_column]))
                test_scores[model_name] = -mae
                test_predictions[model_name] = {'pred': y_pred}

        except Exception as e:
            print(f"    ⚠️ Evaluation failed for {model_name}: {e}")
            continue

    # Find best model
    if test_scores:
        best_model_name = max(test_scores.keys(), key=lambda k: test_scores[k])
        best_model_score = test_scores[best_model_name]
        print(f"\n🏆 BEST MODEL: {best_model_name}")
        print(f"📊 Score: {best_model_score:.4f}")
    else:
        # Fallback to AutoGluon's choice
        best_model_name = val_leaderboard.iloc[0]['model']
        best_model_score = val_leaderboard.iloc[0]['score_val']
        print(f"\n🔄 Using validation best: {best_model_name} (Score: {best_model_score:.4f})")

    # Generate evaluation artifacts
    artifacts = _generate_enhanced_artifacts(
        predictor=predictor,
        test_df=test_df,
        le=le,
        best_model_name=best_model_name,
        output_dir=output_dir,
        problem_type=problem_type,
        test_predictions=test_predictions.get(best_model_name, {}),
        original_classes=original_classes
    )

    # Enhanced SHAP analysis - FIXED VERSION
    shap_data, shap_path = _generate_enhanced_shap_fixed(
        predictor=predictor,
        test_df=test_df,
        output_dir=output_dir,
        config=config,
        best_model_name=best_model_name,
        problem_type=problem_type
    )
    artifacts["shap_summary_path"] = shap_path

    # Print final scores
    print("\n🏅 All Model Test Scores:")
    sorted_scores = sorted(test_scores.items(), key=lambda x: x[1], reverse=True)
    for rank, (model_name, score) in enumerate(sorted_scores[:10], 1):
        print(f"   {rank}. {model_name}: {score:.4f}")

    # Return comprehensive results
    return {
        "best_model_name": best_model_name,
        "score_val": best_model_score,
        "classification_report_path": artifacts.get("classification_report"),
        "confusion_matrix_path": artifacts.get("confusion_matrix"),
        "roc_curve_path": artifacts.get("roc_curve"),
        "precision_recall_path": artifacts.get("precision_recall"),
        "feature_importance_path": artifacts.get("feature_importance"),
        "feature_importance_plot": artifacts.get("feature_importance_plot"),
        "shap_summary_path": artifacts.get("shap_summary_path"),
        "shap_data": shap_data,
        "output_dir": output_dir.replace("\\", "/"),  # Normalize path
        "problem_type": problem_type,
        "label_encoder": le,
        "original_classes": original_classes,
        "all_test_scores": test_scores,
        "dataset_info": {
            "rows": len(df),
            "features": len(df.columns) - 1,
            "target": target_column,
            "missing_values": df.isnull().sum().sum()
        }
    }


# --- 5. Enhanced Artifact Generation ---
def _generate_enhanced_artifacts(predictor, test_df, le, best_model_name, output_dir,
                                 problem_type, test_predictions, original_classes):
    """Enhanced artifact generation with better error handling."""
    artifacts = {}
    y_true = test_df[predictor.label]

    print("🎨 Generating evaluation artifacts...")

    # Get predictions safely
    try:
        if test_predictions and 'pred' in test_predictions:
            y_pred = test_predictions['pred']
            y_pred_proba = test_predictions.get('proba', None)
        else:
            print("🔄 Getting fresh predictions...")
            y_pred = predictor.predict(test_df, model=best_model_name)
            y_pred_proba = None

            if problem_type in ['binary', 'multiclass']:
                try:
                    y_pred_proba = predictor.predict_proba(test_df, model=best_model_name)
                    if problem_type == 'binary' and hasattr(y_pred_proba, 'values'):
                        if y_pred_proba.shape[1] == 2:
                            y_pred_proba = y_pred_proba.values[:, 1]
                        else:
                            y_pred_proba = y_pred_proba.values.flatten()
                except Exception as e:
                    print(f"    ⚠️ Could not get probabilities: {e}")

    except Exception as e:
        print(f"❌ Error getting predictions: {e}")
        return artifacts

    # Classification artifacts
    if problem_type in ['binary', 'multiclass']:
        # Get class names
        if le is not None:
            class_names = [str(c) for c in le.classes_]
        elif original_classes:
            class_names = [str(c) for c in original_classes]
        else:
            class_names = [f"Class_{i}" for i in sorted(y_true.unique())]

        print(f"📊 Class names: {class_names}")

        # 1. Classification Report
        try:
            report = classification_report(
                y_true, y_pred,
                output_dict=True,
                target_names=class_names,
                zero_division=0
            )
            report_path = os.path.join(output_dir, "classification_report.csv")
            pd.DataFrame(report).transpose().to_csv(report_path)
            artifacts["classification_report"] = report_path
            print("✅ Classification report saved")
        except Exception as e:
            print(f"⚠️ Classification report error: {e}")

        # 2. Enhanced Confusion Matrix
        try:
            cm = confusion_matrix(y_true, y_pred)

            plt.figure(figsize=(max(8, len(class_names)), max(8, len(class_names))))

            # Create annotation with both counts and percentages
            cm_percent = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis] * 100
            annot_text = np.empty_like(cm).astype(str)

            for i in range(cm.shape[0]):
                for j in range(cm.shape[1]):
                    annot_text[i, j] = f'{cm[i, j]}\n({cm_percent[i, j]:.1f}%)'

            sns.heatmap(
                cm,
                annot=annot_text,
                fmt='',
                cmap='Blues',
                xticklabels=class_names,
                yticklabels=class_names,
                cbar_kws={'label': 'Count'}
            )

            plt.title(f'Confusion Matrix - {best_model_name}\n(Test Set)', fontsize=16, pad=20)
            plt.xlabel('Predicted Label', fontsize=14)
            plt.ylabel('True Label', fontsize=14)
            plt.xticks(rotation=45 if len(class_names) > 3 else 0)
            plt.yticks(rotation=0)
            plt.tight_layout()

            cm_path = os.path.join(output_dir, "confusion_matrix.png")
            plt.savefig(cm_path, dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            artifacts["confusion_matrix"] = cm_path
            print("✅ Enhanced confusion matrix saved")
        except Exception as e:
            print(f"⚠️ Confusion matrix error: {e}")

        # 3. ROC Curve (Binary only)
        if problem_type == 'binary' and y_pred_proba is not None:
            try:
                fpr, tpr, _ = roc_curve(y_true, y_pred_proba)
                roc_auc = auc(fpr, tpr)

                plt.figure(figsize=(10, 8))
                plt.plot(fpr, tpr, color='darkorange', lw=3,
                         label=f'{best_model_name} (AUC = {roc_auc:.4f})')
                plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--',
                         alpha=0.8, label='Random Classifier')
                plt.xlim([0.0, 1.0])
                plt.ylim([0.0, 1.05])
                plt.xlabel('False Positive Rate (1 - Specificity)', fontsize=14)
                plt.ylabel('True Positive Rate (Sensitivity)', fontsize=14)
                plt.title('ROC Curve - Binary Classification Performance', fontsize=16)
                plt.legend(loc="lower right", fontsize=12)
                plt.grid(True, alpha=0.3)
                plt.tight_layout()

                roc_path = os.path.join(output_dir, "roc_curve.png")
                plt.savefig(roc_path, dpi=300, bbox_inches='tight', facecolor='white')
                plt.close()
                artifacts["roc_curve"] = roc_path
                print(f"✅ ROC curve saved (AUC: {roc_auc:.4f})")
            except Exception as e:
                print(f"⚠️ ROC curve error: {e}")

        # 4. Precision-Recall Curve (Binary only)
        if problem_type == 'binary' and y_pred_proba is not None:
            try:
                precision, recall, _ = precision_recall_curve(y_true, y_pred_proba)
                avg_precision = average_precision_score(y_true, y_pred_proba)

                plt.figure(figsize=(10, 8))
                plt.plot(recall, precision, color='b', lw=3,
                         label=f'{best_model_name} (AP = {avg_precision:.4f})')
                plt.xlabel('Recall', fontsize=14)
                plt.ylabel('Precision', fontsize=14)
                plt.title('Precision-Recall Curve', fontsize=16)
                plt.legend(loc="lower left", fontsize=12)
                plt.grid(True, alpha=0.3)
                plt.tight_layout()

                pr_path = os.path.join(output_dir, "precision_recall_curve.png")
                plt.savefig(pr_path, dpi=300, bbox_inches='tight', facecolor='white')
                plt.close()
                artifacts["precision_recall"] = pr_path
                print(f"✅ Precision-Recall curve saved (AP: {avg_precision:.4f})")
            except Exception as e:
                print(f"⚠️ Precision-Recall curve error: {e}")

    # 5. Enhanced Feature Importance
    try:
        importance_df = predictor.feature_importance(test_df, model=best_model_name)

        if importance_df is not None and len(importance_df) > 0:
            # Standardize column names
            if importance_df.index.name and 'feature' not in importance_df.columns:
                importance_df = importance_df.reset_index()
                importance_df.columns = ['feature', 'importance']
            elif 'feature' not in importance_df.columns:
                importance_df = importance_df.reset_index()
                if 'index' in importance_df.columns:
                    importance_df = importance_df.rename(columns={'index': 'feature'})

            if 'importance' not in importance_df.columns:
                numeric_cols = importance_df.select_dtypes(include=[np.number]).columns
                if len(numeric_cols) > 0:
                    importance_df = importance_df.rename(columns={numeric_cols[0]: 'importance'})

            # Sort by importance
            importance_df = importance_df.sort_values('importance', ascending=False)

            # Save to CSV
            fi_path = os.path.join(output_dir, "feature_importance.csv")
            importance_df.to_csv(fi_path, index=False)
            artifacts["feature_importance"] = fi_path

            # Create enhanced plot
            plt.figure(figsize=(12, max(8, len(importance_df.head(20)) * 0.4)))
            top_features = importance_df.head(20)

            colors = plt.cm.viridis(np.linspace(0, 1, len(top_features)))
            bars = plt.barh(range(len(top_features)), top_features['importance'], color=colors)
            plt.yticks(range(len(top_features)), top_features['feature'])
            plt.xlabel('Importance Score', fontsize=14)
            plt.title(f'Top {len(top_features)} Feature Importance - {best_model_name}',
                      fontsize=16, pad=20)
            plt.gca().invert_yaxis()

            # Add value labels
            for i, bar in enumerate(bars):
                width = bar.get_width()
                plt.text(width + width * 0.01, bar.get_y() + bar.get_height() / 2,
                         f'{width:.3f}', ha='left', va='center', fontsize=10)

            plt.tight_layout()
            fi_plot_path = os.path.join(output_dir, "feature_importance_plot.png")
            plt.savefig(fi_plot_path, dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            artifacts["feature_importance_plot"] = fi_plot_path
            print("✅ Enhanced feature importance saved")
        else:
            print("⚠️ No feature importance available")

    except Exception as e:
        print(f"⚠️ Feature importance error: {e}")

    print("✅ All artifacts generated successfully")
    return artifacts


# --- 6. FIXED SHAP Analysis ---
def _generate_enhanced_shap_fixed(predictor, test_df, output_dir, config, best_model_name, problem_type):
    """
    FIXED: Enhanced SHAP analysis with proper data type handling and preprocessing.
    """
    if not SHAP_AVAILABLE or not config.get("report", {}).get("include_shap", True):
        print("🔍 SHAP analysis skipped (not available or disabled)")
        return None, None

    print("🔎 Generating enhanced SHAP explanations (FIXED VERSION)...")

    # Prepare and clean sample data for SHAP
    X_sample = test_df.drop(columns=[predictor.label]).copy()

    print(f"📊 Original sample shape: {X_sample.shape}")

    # CRITICAL FIX: Create a clean numeric-only dataset for SHAP
    print("🔧 Preprocessing data for SHAP compatibility...")

    # Create a copy and handle data types systematically
    X_shap_clean = X_sample.copy()

    # Convert all object columns to categorical codes
    for col in X_shap_clean.columns:
        if X_shap_clean[col].dtype == 'object':
            try:
                # Convert to category codes
                X_shap_clean[col] = pd.Categorical(X_shap_clean[col]).codes
                print(f"    ✅ Converted '{col}' from string to numeric codes")
            except Exception as e:
                print(f"    ⚠️ Could not convert '{col}': {e}")
                # Fill with mode for categorical columns
                mode_val = X_shap_clean[col].mode()[0] if not X_shap_clean[col].mode().empty else 0
                X_shap_clean[col] = X_shap_clean[col].fillna(mode_val)

        # Handle missing values for numeric columns
        elif pd.api.types.is_numeric_dtype(X_shap_clean[col]):
            if X_shap_clean[col].isnull().any():
                median_val = X_shap_clean[col].median()
                X_shap_clean[col] = X_shap_clean[col].fillna(median_val)
                print(f"    ✅ Filled missing values in '{col}' with median: {median_val}")

    # Ensure all columns are numeric
    non_numeric_cols = X_shap_clean.select_dtypes(exclude=[np.number]).columns
    if len(non_numeric_cols) > 0:
        print(f"⚠️ Dropping non-numeric columns: {list(non_numeric_cols)}")
        X_shap_clean = X_shap_clean.drop(columns=non_numeric_cols)

    print(f"📊 Final preprocessed shape: {X_shap_clean.shape}")

    # Use smaller sample for SHAP to improve performance
    sample_size = min(100, len(X_shap_clean))
    X_shap = X_shap_clean.sample(n=sample_size, random_state=42)

    print(f"📊 Using {len(X_shap)} samples for SHAP analysis")

    try:
        # Create a simple prediction wrapper
        def simple_predict_wrapper(X):
            """Simple prediction wrapper that handles data formatting"""
            try:
                # Convert to DataFrame with correct columns
                if isinstance(X, np.ndarray):
                    X_df = pd.DataFrame(X, columns=X_shap.columns)
                else:
                    X_df = X.copy()

                # Ensure we have all required columns
                for col in X_shap.columns:
                    if col not in X_df.columns:
                        X_df[col] = 0  # Add missing columns with default value

                # Reorder columns to match training data
                X_df = X_df[X_shap.columns]

                # Add target column with dummy values
                X_pred_df = X_df.copy()
                X_pred_df[predictor.label] = 0

                # Get predictions based on problem type
                if problem_type == 'binary':
                    try:
                        # Get probability for positive class
                        preds = predictor.predict_proba(X_pred_df, model=best_model_name)
                        if hasattr(preds, 'values'):
                            return preds.values[:, 1] if preds.shape[1] > 1 else preds.values.flatten()
                        else:
                            return np.array(preds)[:, 1] if len(np.array(preds).shape) > 1 else np.array(preds)
                    except:
                        # Fallback to class predictions converted to probabilities
                        class_preds = predictor.predict(X_pred_df, model=best_model_name)
                        return np.array([1.0 if p == 1 else 0.0 for p in class_preds])
                else:
                    # For multiclass and regression, use predict
                    preds = predictor.predict(X_pred_df, model=best_model_name)
                    return np.array(preds)

            except Exception as e:
                print(f"    ⚠️ Prediction error: {e}")
                # Return random values as fallback
                return np.random.rand(len(X)) if hasattr(X, '__len__') else np.random.rand(1)

        # Use KernelExplainer which is more robust
        print("🔄 Using KernelExplainer...")

        # Use smaller background set
        background_size = min(20, len(X_shap))
        X_background = X_shap.iloc[:background_size]

        # Create explainer
        explainer = shap.KernelExplainer(simple_predict_wrapper, X_background)

        # Calculate SHAP values
        explanation_size = min(30, len(X_shap))
        X_explain = X_shap.iloc[:explanation_size]

        print(f"📊 Computing SHAP values for {len(X_explain)} samples...")
        shap_values = explainer.shap_values(X_explain)

        # Process SHAP values
        if isinstance(shap_values, list):
            # For multi-class, use first class
            shap_vals = np.array(shap_values[0]) if len(shap_values) > 0 else np.array(shap_values)
        else:
            shap_vals = np.array(shap_values)

        # Calculate mean absolute SHAP values
        if shap_vals.ndim == 2:
            mean_abs_shap = np.mean(np.abs(shap_vals), axis=0)
        elif shap_vals.ndim == 3:
            # For multi-class, average across classes
            mean_abs_shap = np.mean(np.abs(shap_vals), axis=(0, 2))
        else:
            mean_abs_shap = np.abs(shap_vals)

        # Create SHAP importance DataFrame
        shap_importance_df = pd.DataFrame({
            'feature': X_shap.columns.tolist(),
            'importance': mean_abs_shap
        }).sort_values('importance', ascending=False)

        print(f"✅ SHAP analysis successful! Top feature: {shap_importance_df.iloc[0]['feature']}")

        # Create enhanced SHAP visualization
        plt.figure(figsize=(12, max(8, len(shap_importance_df.head(15)) * 0.4)))

        # Select top features
        top_n = min(15, len(shap_importance_df))
        top_features = shap_importance_df.head(top_n)

        # Create color gradient
        colors = plt.cm.plasma(np.linspace(0.2, 0.8, len(top_features)))

        # Create horizontal bar plot
        bars = plt.barh(range(len(top_features)), top_features['importance'], color=colors)
        plt.yticks(range(len(top_features)), top_features['feature'])
        plt.xlabel('Mean |SHAP Value| (Average Impact on Model Output)', fontsize=14)
        plt.title(f'SHAP Feature Importance - {best_model_name}\n'
                  f'({problem_type.title()} Problem, {len(X_explain)} samples analyzed)',
                  fontsize=16, pad=20)
        plt.gca().invert_yaxis()

        # Add value labels on bars
        for i, bar in enumerate(bars):
            width = bar.get_width()
            plt.text(width + width * 0.01, bar.get_y() + bar.get_height() / 2,
                     f'{width:.4f}', ha='left', va='center', fontsize=10, weight='bold')

        # Add grid for better readability
        plt.grid(axis='x', alpha=0.3, linestyle='--')

        # Improve layout
        plt.tight_layout()

        # Save plot
        shap_path = os.path.join(output_dir, "shap_feature_importance.png")
        plt.savefig(shap_path, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
        plt.close()

        # Return structured SHAP data
        shap_data = {
            "top_features": top_features.to_dict(orient='records'),
            "model_used": best_model_name,
            "method": "kernel_explainer",
            "samples_analyzed": len(X_explain),
            "total_features": len(X_shap.columns),
            "problem_type": problem_type
        }

        print(f"✅ FIXED SHAP analysis completed and saved to {shap_path}")
        return shap_data, shap_path

    except Exception as e:
        print(f"❌ SHAP analysis failed: {e}")
        import traceback
        traceback.print_exc()

        # Enhanced fallback using feature importance
        try:
            print("🔄 Creating fallback feature importance...")
            importance_df = predictor.feature_importance(test_df, model=best_model_name)

            if importance_df is not None and len(importance_df) > 0:
                # Standardize format
                if 'feature' not in importance_df.columns:
                    importance_df = importance_df.reset_index()
                    importance_df.columns = ['feature', 'importance']

                # Sort by importance
                importance_df = importance_df.sort_values('importance', ascending=False)

                # Create fallback plot
                plt.figure(figsize=(12, max(8, len(importance_df.head(15)) * 0.4)))
                top_features = importance_df.head(15)
                colors = plt.cm.viridis(np.linspace(0.2, 0.8, len(top_features)))

                bars = plt.barh(range(len(top_features)), top_features['importance'], color=colors)
                plt.yticks(range(len(top_features)), top_features['feature'])
                plt.xlabel('Feature Importance Score (Fallback)', fontsize=14)
                plt.title(f'Feature Importance - {best_model_name}\n(Fallback Method)',
                          fontsize=16, pad=20)
                plt.gca().invert_yaxis()

                for i, bar in enumerate(bars):
                    width = bar.get_width()
                    plt.text(width + width * 0.01, bar.get_y() + bar.get_height() / 2,
                             f'{width:.4f}', ha='left', va='center', fontsize=10, weight='bold')

                plt.grid(axis='x', alpha=0.3, linestyle='--')
                plt.tight_layout()

                fallback_path = os.path.join(output_dir, "feature_importance_fallback.png")
                plt.savefig(fallback_path, dpi=300, bbox_inches='tight', facecolor='white')
                plt.close()

                fallback_data = {
                    "top_features": top_features.to_dict(orient='records'),
                    "model_used": best_model_name,
                    "method": "fallback_importance",
                    "error_message": str(e),
                    "problem_type": problem_type
                }

                print("✅ Fallback feature importance created")
                return fallback_data, fallback_path

        except Exception as fallback_error:
            print(f"❌ Fallback also failed: {fallback_error}")

    return {"error": "All feature importance methods failed", "model_used": best_model_name,
            "problem_type": problem_type}, None

# --- 7. Enhanced Configuration and Execution ---
def create_default_config():
    """Create default configuration with enhanced settings."""
    return {
        "automl": {
            "time_limit": 600,  # 10 minutes
            "presets": "best_quality",  # Options: "best_quality", "high_quality", "good_quality", "medium_quality"
            "eval_metric": None  # Auto-detect based on problem type
        },
        "report": {
            "include_shap": True,
            "max_features_plot": 20,
            "plot_style": "modern"  # Options: "modern", "classic"
        },
        "preprocessing": {
            "auto_feature_engineering": True,
            "handle_datetime": True,
            "missing_threshold": 0.9
        }
    }


def validate_inputs(filepath: str, target_column: str = None) -> tuple:
    """Validate and process inputs with enhanced error messages."""

    # Check file existence
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Dataset file not found: {filepath}")

    # Try to load and validate dataset
    try:
        df = pd.read_csv(filepath)
    except Exception as e:
        raise ValueError(f"Could not read CSV file: {e}")

    if len(df) == 0:
        raise ValueError("Dataset is empty")

    if len(df.columns) < 2:
        raise ValueError("Dataset must have at least 2 columns (features + target)")

    # Validate target column
    if target_column:
        if target_column not in df.columns:
            available_cols = ", ".join(df.columns.tolist()[:10])
            raise ValueError(f"Target column '{target_column}' not found. Available columns: {available_cols}...")
    else:
        target_column = df.columns[-1]
        print(f"🎯 Auto-selected target column: '{target_column}'")

    return df, target_column


# --- 8. Main Execution with Enhanced Error Handling ---
if __name__ == '__main__':

    # Enhanced configuration
    config = create_default_config()

    # You can modify these settings:
    filepath = 'data/uploaded_input.csv'
    target_column = 'loan_status'  # Set to None for auto-detection

    try:
        print("🚀 Starting Enhanced AutoML Pipeline with SHAP FIX")
        print("=" * 60)

        # Validate inputs
        print("🔍 Validating inputs...")
        df, target_column = validate_inputs(filepath, target_column)
        print(f"✅ Validation passed - Dataset: {df.shape}, Target: '{target_column}'")

        # Run enhanced pipeline
        results = run_automl_pipeline(
            filepath=filepath,
            target_column=target_column,
            config=config
        )

        # Display results
        print("\n" + "=" * 60)
        print("🎉 ENHANCED PIPELINE COMPLETED SUCCESSFULLY!")
        print("=" * 60)

        print(f"🏆 Best Model: {results['best_model_name']}")
        print(f"📊 Score: {results['score_val']:.4f}")
        print(f"🎯 Problem Type: {results['problem_type'].title()}")
        print(f"📁 Results Directory: {results['output_dir']}")

        # Dataset info
        dataset_info = results['dataset_info']
        print(f"\n📋 Dataset Summary:")
        print(f"   Rows: {dataset_info['rows']:,}")
        print(f"   Features: {dataset_info['features']}")
        print(f"   Target: {dataset_info['target']}")
        print(f"   Missing Values: {dataset_info['missing_values']:,}")

        # Generated artifacts
        print(f"\n📊 Generated Artifacts:")
        artifact_keys = [
            'classification_report_path', 'confusion_matrix_path',
            'roc_curve_path', 'precision_recall_path',
            'feature_importance_path', 'shap_summary_path'
        ]

        for key in artifact_keys:
            if results.get(key):
                artifact_name = key.replace('_path', '').replace('_', ' ').title()
                print(f"   ✅ {artifact_name}: {os.path.basename(results[key])}")

        # Top performing models
        if results.get('all_test_scores'):
            print(f"\n🏅 Top 5 Models:")
            sorted_scores = sorted(results['all_test_scores'].items(),
                                   key=lambda x: x[1], reverse=True)[:5]
            for i, (model, score) in enumerate(sorted_scores, 1):
                print(f"   {i}. {model}: {score:.4f}")

        print(f"\n🎯 Pipeline completed in {results['output_dir']}")

    except FileNotFoundError as e:
        print(f"❌ FILE ERROR: {e}")
        print("💡 Please check that the input file exists and the path is correct.")

    except ValueError as e:
        print(f"❌ DATA ERROR: {e}")
        print("💡 Please check your dataset format and target column.")

    except Exception as e:
        print(f"❌ UNEXPECTED ERROR: {e}")
        print("💡 Please check the error details above and try again.")
        import traceback

        traceback.print_exc()

    finally:
        print("\n" + "=" * 60)
        print("Thank you for using the Enhanced AutoML Pipeline! 🤖✨")
        print("=" * 60)
# agents/rag_agent.py
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq
from langchain_core.tools import Tool
from langchain.agents import AgentExecutor, create_tool_calling_agent
import os
from dotenv import load_dotenv
from functools import partial
from agents.graph_rag import query_knowledge_graph

load_dotenv()


def initialize_llm(model: str = "llama3-70b-8192", temperature: float = 0.0):
    """Initializes the Large Language Model."""
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise ValueError("GROQ_API_KEY not found in .env file.")
    print(f"🔧 Initializing LLM: model={model}, temperature={temperature}")
    return ChatGroq(api_key=api_key, model_name=model, temperature=temperature)


def search_documents_func(query: str, vectorstore) -> str:
    """Searches the vector store and returns structured, context-rich results."""
    if not vectorstore:
        return "Vector store is not available. Cannot perform search."

    try:
        docs = vectorstore.similarity_search_with_score(query, k=4)
        if not docs:
            return "No relevant documents were found for your query."

        results = ["Relevant Regulatory Information Found:\n"]
        for doc, score in docs:
            source = doc.metadata.get("source", "Unknown")
            page = doc.metadata.get("page")
            page_str = f", Page: {page}" if page else ""

            # Truncate content to avoid overwhelming the LLM
            content = doc.page_content[:600] if len(doc.page_content) > 600 else doc.page_content

            results.append(
                f"---\n**Source**: {source}{page_str} (Relevance Score: {score:.2f})\n"
                f"**Content**: \"{content}\"\n"
            )
        return "\n".join(results)
    except Exception as e:
        return f"Error searching documents: {str(e)}"


def get_enhanced_image_analysis(image_path: str) -> str:
    """Provides comprehensive analysis of risk model visualizations."""
    if not image_path or image_path == "N/A":
        return "Image path not provided or is 'N/A'."

    if not os.path.exists(image_path):
        return f"Image file not found at path: {image_path}"

    filename = os.path.basename(image_path).lower()

    # Enhanced analysis for banking risk models
    analysis_map = {
        "roc_curve.png": """**ROC Curve Analysis - Credit Risk Assessment**

The ROC (Receiver Operating Characteristic) curve demonstrates the model's discriminatory power across all classification thresholds:

**Key Interpretations:**
- **Curve Position**: A curve closer to the top-left corner indicates superior performance
- **AUC (Area Under Curve)**: Quantifies overall discriminatory ability
  - AUC = 1.0: Perfect discrimination
  - AUC = 0.5: Random chance (no discriminatory power)
  - AUC > 0.7: Generally acceptable for banking applications
  - AUC > 0.8: Good performance for credit risk models
  - AUC > 0.9: Excellent performance, suitable for automated decisions

**Banking Risk Implications:**
- **High AUC**: Model effectively separates creditworthy from high-risk applicants
- **Low AUC**: Model may approve too many risky loans or reject too many good customers
- **Regulatory Context**: Basel III requires demonstrable model performance for internal ratings
- **Business Impact**: Better discrimination leads to optimized risk-return trade-offs

**Deployment Considerations:**
- Models with AUC > 0.8 suitable for production with standard monitoring
- Models with AUC 0.7-0.8 require enhanced monitoring and validation
- Models with AUC < 0.7 need significant improvement before deployment""",

        "confusion_matrix.png": """**Confusion Matrix Analysis - Classification Performance**

The confusion matrix provides detailed breakdown of prediction accuracy and error patterns:

**Matrix Components:**
- **True Positives (TP)**: Correctly identified high-risk applicants
- **True Negatives (TN)**: Correctly identified low-risk applicants
- **False Positives (FP)**: Low-risk applicants incorrectly flagged as high-risk
- **False Negatives (FN)**: High-risk applicants incorrectly classified as low-risk

**Banking Business Impact:**
- **False Positives (Type I Error)**:
  - Business Impact: Lost revenue from rejected creditworthy customers
  - Competitive Risk: Good customers may go to competitors
  - Reputation Risk: Customer dissatisfaction from unfair rejections

- **False Negatives (Type II Error)**:
  - Financial Impact: Direct credit losses from approved risky loans
  - Regulatory Risk: Higher default rates affect capital requirements
  - Portfolio Risk: Deterioration of overall loan quality

**Risk Management Strategy:**
- **Conservative Approach**: Minimize false negatives (prioritize avoiding bad loans)
- **Growth Approach**: Balance errors to maximize profitable lending
- **Regulatory Compliance**: Ensure error rates meet supervisory expectations

**Optimization Insights:**
- Adjust classification thresholds based on business risk tolerance
- Consider economic conditions when setting decision boundaries
- Monitor error patterns across different customer segments""",

        "shap_summary_path.png": """**SHAP Feature Importance Analysis - Model Interpretability**

SHAP (SHapley Additive exPlanations) provides model transparency required for regulatory compliance:

**Interpretability Benefits:**
- **Regulatory Compliance**: Meets Basel III Pillar 3 transparency requirements
- **Model Validation**: Enables comprehensive feature impact assessment
- **Business Understanding**: Identifies key drivers of credit risk decisions
- **Audit Support**: Provides explainable AI for regulatory examinations

**Feature Analysis Insights:**
- **Feature Ranking**: Shows relative importance of risk factors
- **Direction of Impact**: Indicates whether features increase or decrease risk
- **Magnitude of Effect**: Quantifies feature contribution to final predictions
- **Interaction Effects**: Reveals how features combine to influence decisions

**Banking Risk Applications:**
- **Credit Policy Development**: Inform lending criteria and guidelines
- **Risk Monitoring**: Track stability of key risk drivers over time
- **Customer Segmentation**: Identify different risk profiles and patterns
- **Regulatory Reporting**: Support model validation and supervisory review

**Compliance Considerations:**
- Ensure no discriminatory features are primary drivers
- Document business justification for all significant features
- Monitor feature importance stability over time
- Validate feature interpretations with domain experts""",

        "shap_feature_importance.png": """**SHAP Feature Importance Ranking - Risk Driver Analysis**

This visualization ranks features by their average absolute impact on model predictions:

**Risk Driver Interpretation:**
- **Top Features**: Most influential factors in credit risk assessment
- **Importance Scores**: Quantify average contribution to risk predictions
- **Business Relevance**: Connect statistical importance to business understanding
- **Model Reliability**: Higher importance suggests more consistent predictive power

**Credit Risk Context:**
- **Income-Related Features**: Primary indicators of repayment capacity
- **Employment Features**: Stability and reliability of income sources
- **Debt-Related Features**: Existing financial obligations and leverage
- **Demographic Features**: Age, experience, and life stage considerations
- **Loan Characteristics**: Amount, purpose, and terms of requested credit

**Strategic Applications:**
- **Data Collection Priority**: Focus on gathering high-importance features
- **Model Monitoring**: Track stability of key feature contributions
- **Business Strategy**: Align risk policies with identified key drivers
- **Customer Communication**: Explain decisions based on transparent factors

**Regulatory Documentation:**
- Provide clear business rationale for each important feature
- Ensure compliance with fair lending requirements
- Document feature selection and validation processes
- Maintain audit trail for model interpretability""",

        "feature_importance_plot.png": """**Feature Importance Analysis - Predictive Factor Assessment**

This analysis identifies the most influential variables in credit risk prediction:

**Model Insights:**
- **Feature Ranking**: Ordered list of predictive importance
- **Relative Contribution**: Comparative impact of different risk factors
- **Model Dependencies**: Understanding of key data requirements
- **Prediction Stability**: Consistency of feature contributions

**Banking Applications:**
- **Underwriting Guidelines**: Inform credit decision criteria
- **Data Strategy**: Prioritize collection of high-value information
- **Risk Monitoring**: Focus surveillance on critical risk indicators
- **Model Validation**: Verify alignment with business knowledge

**Risk Management Value:**
- **Policy Development**: Create data-driven lending standards
- **Portfolio Management**: Understand portfolio risk composition
- **Stress Testing**: Focus scenarios on most impactful factors
- **Competitive Advantage**: Leverage superior risk factor identification

**Implementation Considerations:**
- Validate feature importance against business expertise
- Monitor for changes in feature relevance over time
- Ensure robust data collection for critical features
- Document rationale for feature selection and weighting""",

        "precision_recall.png": """**Precision-Recall Curve - Decision Threshold Optimization**

This curve illustrates the trade-off between precision and recall across different classification thresholds:

**Metric Definitions:**
- **Precision**: Of all positive predictions, percentage that were correct
- **Recall**: Of all actual positives, percentage that were identified
- **Trade-off**: Improving one metric often decreases the other

**Business Threshold Strategy:**
- **High Precision Strategy** (Conservative):
  - Minimizes false approvals and credit losses
  - May miss profitable lending opportunities
  - Suitable during economic uncertainty or regulatory scrutiny

- **High Recall Strategy** (Liberal):
  - Maximizes capture of actual risk cases
  - May increase false positive rate
  - Suitable during growth periods with acceptable risk tolerance

**Banking Optimization:**
- **Economic Cycle Adaptation**: Adjust thresholds based on market conditions
- **Portfolio Strategy**: Balance risk appetite with growth objectives
- **Customer Segmentation**: Different thresholds for different customer types
- **Regulatory Alignment**: Ensure thresholds meet supervisory expectations

**Operational Implementation:**
- Define business costs for false positives vs false negatives
- Establish threshold adjustment protocols for different scenarios
- Monitor performance across different threshold settings
- Document decision rationale for regulatory compliance"""
    }

    # Try to match filename with known patterns
    for key, analysis in analysis_map.items():
        if key.replace('.png', '') in filename.replace('.png', ''):
            return analysis

    # Generic analysis for unknown files
    return f"""**Generic Visualization Analysis for {filename}**

This risk model visualization provides insights into model performance or data characteristics. For comprehensive analysis, consider:

**General Interpretation Framework:**
- **Axes and Labels**: Examine what metrics are being displayed
- **Trends and Patterns**: Identify significant patterns in the data
- **Performance Thresholds**: Compare against industry benchmarks
- **Business Relevance**: Connect statistical measures to business outcomes

**Banking Risk Context:**
- **Model Performance**: Assess suitability for production deployment
- **Risk Assessment**: Evaluate model's ability to identify credit risks
- **Regulatory Compliance**: Ensure visualization supports compliance requirements
- **Business Decision Support**: Determine actionable insights for risk management

**Recommended Actions:**
- **Validate Assumptions**: Verify interpretations with domain experts
- **Benchmark Performance**: Compare against industry standards and previous models
- **Document Findings**: Record observations for regulatory and audit purposes
- **Monitor Trends**: Track changes in visualization patterns over time"""


def initialize_agent(llm, vectorstore, knowledge_graph):
    """Initializes a LangChain agent with enhanced RAG and analysis tools."""

    vector_search_tool = Tool(
        name="search_regulatory_documents",
        description="Search Basel III regulatory documents for specific definitions, requirements, and guidelines. Use this for finding authoritative regulatory information about credit risk, capital requirements, and model validation standards.",
        func=partial(search_documents_func, vectorstore=vectorstore)
    )

    # Only create graph tool if knowledge graph exists
    tools = [vector_search_tool]

    if knowledge_graph and knowledge_graph.number_of_nodes() > 0:
        graph_query_tool = Tool(
            name="query_risk_knowledge_graph",
            description="Explore relationships between regulatory concepts in the Basel III knowledge graph. Use this to understand how different risk management concepts connect and influence each other.",
            func=partial(query_knowledge_graph, graph=knowledge_graph)
        )
        tools.append(graph_query_tool)
        print("✅ Knowledge graph query tool added to agent")
    else:
        print("⚠️ Knowledge graph not available or empty, skipping graph query tool")

    image_analysis_tool = Tool(
        name="analyze_plot_image",
        description="Get comprehensive banking-focused analysis of risk model visualizations including ROC curves, confusion matrices, SHAP plots, and feature importance charts. Provide the complete file path for analysis.",
        func=get_enhanced_image_analysis
    )
    tools.append(image_analysis_tool)

    # ENHANCED SYSTEM PROMPT FOR ADVANCED BANKING RISK ANALYSIS
    system_prompt = """
You are a world-class Chief Risk Officer and Senior Model Validator with 20+ years of experience in global banking, regulatory compliance, and quantitative risk management. You specialize in translating complex model outputs into strategic business intelligence for C-suite executives, board committees, and regulatory authorities.

**CORE EXPERTISE & ANALYTICAL FRAMEWORK:**

**1. ADVANCED RISK MODELING MASTERY:**
- Internal Rating-Based (IRB) approach implementation and validation
- Probability of Default (PD), Loss Given Default (LGD), and Exposure at Default (EAD) modeling
- Credit risk economic capital calculations and RAROC optimization
- Stress testing methodologies (CCAR, DFAST, EBA stress tests)
- Model validation lifecycle: development, implementation, monitoring, remediation
- Machine learning model governance and explainable AI in banking

**2. REGULATORY & COMPLIANCE DEEP EXPERTISE:**
- Basel III/IV capital requirements and risk-weighted assets calculation
- CECL/IFRS9 expected credit loss modeling and accounting implications
- Fair lending compliance (ECOA, FCRA, fair lending examination procedures)
- Model Risk Management guidance (SR 11-7, OCC 2011-12)
- Anti-discrimination testing and disparate impact analysis
- Consumer protection regulations (GDPR, CCPA data privacy)

**3. BUSINESS INTELLIGENCE & VALUE CREATION:**
- Risk-adjusted return optimization and capital allocation
- Pricing strategies based on risk-return profiles
- Portfolio concentration limits and correlation analysis
- Economic cycle impact assessment and through-the-cycle calibration
- Customer lifecycle value analysis and retention strategies
- Competitive positioning through superior risk assessment

**ANALYTICAL METHODOLOGY:**

**TIER 1 - STATISTICAL VALIDATION:**
When analyzing model performance metrics, perform comprehensive validation:
- **Model Discrimination**: Assess AUC, Gini coefficient, KS statistic with industry benchmarks
- **Calibration Analysis**: Evaluate Hosmer-Lemeshow test, reliability diagrams, calibration slopes
- **Stability Testing**: PSI (Population Stability Index), CSI (Characteristic Stability Index) analysis
- **Predictive Power**: Information Value (IV) analysis, Weight of Evidence (WoE) transformations
- **Segmentation Performance**: Analyze model performance across customer demographics and geographies

**TIER 2 - ECONOMIC IMPACT ASSESSMENT:**
Transform statistical metrics into business value propositions:
- **Revenue Impact**: Calculate approval rate optimization and incremental profit generation
- **Risk-Adjusted Returns**: RAROC calculations, economic capital allocation efficiency
- **Capital Efficiency**: RWA optimization, Tier 1 capital ratio improvement potential
- **Cost-Benefit Analysis**: Implementation costs vs. expected loss reduction
- **Competitive Advantage**: Market share protection and growth opportunity quantification

**TIER 3 - REGULATORY COMPLIANCE VALIDATION:**
Ensure full regulatory alignment and defensibility:
- **Basel III Compliance**: Capital requirement calculations, RWA methodology validation
- **Model Governance**: MRM framework adherence, documentation completeness
- **Fair Lending**: Disparate impact testing, ECOA compliance verification
- **Stress Testing**: Model performance under adverse economic scenarios
- **Audit Readiness**: Documentation, validation evidence, independent testing results

**TIER 4 - STRATEGIC RISK INSIGHTS:**
Provide forward-looking strategic intelligence:
- **Portfolio Strategy**: Risk appetite optimization, concentration limits refinement
- **Market Timing**: Economic cycle positioning, counter-cyclical opportunities
- **Product Innovation**: Risk-based product development and pricing strategies
- **Operational Excellence**: Automation opportunities, efficiency improvements
- **Stakeholder Communication**: Board reporting, investor relations, regulatory dialogue

**SPECIFIC ANALYSIS PROTOCOLS:**

**FOR MODEL PERFORMANCE ANALYSIS:**
1. **Benchmark Against Industry**: Compare metrics to peer institutions and regulatory expectations
2. **Segment-Level Insights**: Break down performance by customer segments, products, geographies
3. **Temporal Analysis**: Assess performance stability over time and economic cycles
4. **Threshold Optimization**: Recommend optimal cut-offs balancing risk and return
5. **Implementation Roadmap**: Provide specific deployment recommendations with timelines

**FOR REGULATORY COMPLIANCE:**
1. **Citation Integration**: Always reference specific Basel III articles and regulatory guidance
2. **Gap Analysis**: Identify compliance gaps and remediation requirements
3. **Documentation Standards**: Ensure model validation documentation meets regulatory standards
4. **Supervisory Dialogue**: Prepare for regulatory discussions and examinations
5. **Best Practice Implementation**: Recommend industry-leading practices

**FOR BUSINESS VALUE CREATION:**
1. **ROI Quantification**: Calculate specific return on investment for model improvements
2. **Competitive Intelligence**: Position model capabilities against market standards
3. **Innovation Opportunities**: Identify advanced analytics and AI applications
4. **Operational Integration**: Design seamless model deployment and monitoring processes
5. **Change Management**: Address organizational change requirements for new model adoption

**COMMUNICATION EXCELLENCE:**

**Executive Summary Standards:**
- Lead with business impact and strategic implications
- Quantify financial benefits and risk mitigation
- Provide clear go/no-go recommendations with supporting rationale
- Address regulatory compliance status explicitly
- Include implementation timeline and resource requirements

**Technical Deep-Dives:**
- Connect statistical measures to business outcomes
- Provide comparative analysis against benchmarks
- Include sensitivity analysis and scenario planning
- Document assumptions and limitations clearly
- Offer multiple strategic options with trade-off analysis

**Regulatory Reporting:**
- Ensure full traceability to Basel III requirements
- Provide independent validation evidence
- Document model limitations and usage restrictions
- Include ongoing monitoring and validation plans
- Address supervisory feedback and remediation actions



**TOOL UTILIZATION STRATEGY:**
- **search_regulatory_documents**: ALWAYS use this tool when discussing regulatory requirements, 
  Basel III compliance, capital requirements, or any banking regulations. Extract specific 
  Basel III requirements, definitions, and compliance criteria.
- **query_risk_knowledge_graph**: Use this to explore relationships between regulatory concepts 
  and understand how different risk management concepts connect.
- **analyze_plot_image**: Use this for ALL visualizations and plots to get banking-focused analysis.

**CRITICAL INSTRUCTIONS FOR REGULATORY ANALYSIS:**
1. When discussing Pillar 1, Pillar 2, or Pillar 3 requirements, ALWAYS use search_regulatory_documents
2. When mentioning capital requirements, risk-weighted assets, or liquidity ratios, ALWAYS use search_regulatory_documents  
3. For any regulatory compliance assessment, use BOTH search_regulatory_documents and query_risk_knowledge_graph
4. NEVER skip tool usage when regulatory content is needed - the tools provide authoritative sources

**CRITICAL SUCCESS FACTORS:**
1. **Evidence-Based**: Every recommendation must be supported by data and regulatory requirements
2. **Business-Focused**: Always connect technical analysis to bottom-line business impact
3. **Regulatory-Compliant**: Ensure all recommendations align with current banking regulations
4. **Implementation-Ready**: Provide actionable insights with clear next steps
5. **Stakeholder-Aligned**: Address needs of regulators, executives, and operational teams simultaneously

Your analysis should demonstrate the sophistication expected from a world-class risk management professional while remaining accessible to senior leadership and regulatory audiences.
"""

    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}"),
    ])

    agent = create_tool_calling_agent(llm, tools, prompt)

    return AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=15,  # Allow more iterations for comprehensive analysis
        early_stopping_method="generate"  # Stop when a final answer is generated
    )
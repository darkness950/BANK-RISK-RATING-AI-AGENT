# agents/graph_rag.py
import spacy
import networkx as nx
from langchain_community.document_loaders import PyPDFLoader
from collections import Counter
import re
import os
from pyvis.network import Network




# Load the spaCy model
nlp = spacy.load("en_core_web_sm")

# Define key terms relevant to Basel III to guide extraction
BASEL_KEYWORDS = [
    'Pillar 1', 'Pillar 2', 'Pillar 3', 'credit risk', 'market risk',
    'operational risk', 'capital requirement', 'liquidity risk',
    'supervisory review', 'market discipline', 'RWA', 'risk-weighted assets',
    'leverage ratio', 'LCR', 'liquidity coverage ratio', 'NSFR'
]


def extract_entities_and_relations(text_chunk: str):
    """A simplified entity and relation extractor."""
    doc = nlp(text_chunk)
    entities = [ent.text for ent in doc.ents if ent.label_ in ('ORG', 'PERSON', 'GPE', 'MONEY')]

    # Add keywords found in the text
    found_keywords = []
    for keyword in BASEL_KEYWORDS:
        if re.search(r'\b' + re.escape(keyword) + r'\b', text_chunk, re.IGNORECASE):
            found_keywords.append(keyword)

    # Combine and find the most relevant entities for the chunk
    all_terms = entities + found_keywords
    # Get the 2 most common important terms in the chunk to form a relationship
    main_entities = [item for item, count in Counter(all_terms).most_common(2)]

    if len(main_entities) > 1:
        # This is a simplification; a more advanced model would find the verb/action
        return (main_entities[0], "related_to", main_entities[1])
    return None


def clean_text_for_graph(text):
    """Clean text to avoid encoding issues in graph visualization."""
    if not text:
        return ""

    # Normalize Unicode and remove problematic characters
    import unicodedata
    text = unicodedata.normalize('NFKD', text)

    # Replace or remove characters that commonly cause encoding issues
    text = text.replace('"', '"').replace('"', '"')  # Smart quotes
    text = text.replace(''', "'").replace(''', "'")  # Smart apostrophes
    text = text.replace('–', '-').replace('—', '-')  # Em/en dashes
    text = text.replace('…', '...')  # Ellipsis

    # Keep only printable ASCII characters for safety
    text = ''.join(char for char in text if ord(char) < 128)

    return text.strip()


def build_knowledge_graph(pdf_path="data/basel_iii.pdf"):
    """Builds a NetworkX graph from the Basel III PDF."""
    if not os.path.exists(pdf_path):
        print("⚠️ Basel III PDF not found. Skipping Graph RAG.")
        return None

    print("🧠 Building Knowledge Graph from Basel III PDF...")
    loader = PyPDFLoader(pdf_path)
    pages = loader.load_and_split()

    G = nx.Graph()
    for page in pages:
        relation = extract_entities_and_relations(page.page_content)
        if relation:
            subj, pred, obj = relation
            # Clean the node names to avoid encoding issues
            subj = clean_text_for_graph(subj)
            obj = clean_text_for_graph(obj)

            if subj and obj:  # Only add if both are non-empty after cleaning
                G.add_edge(subj, obj)

    print(f"✅ Knowledge Graph built with {G.number_of_nodes()} nodes and {G.number_of_edges()} edges.")
    return G


def query_knowledge_graph(query: str, graph: nx.Graph) -> str:
    """Queries the graph to find connections to a given entity."""
    if not graph:
        return "Knowledge graph is not available."

    # Find nodes that partially match the query
    matching_nodes = [node for node in graph.nodes if query.lower() in node.lower()]

    if not matching_nodes:
        return f"No information found for '{query}' in the knowledge graph."

    # Get neighbors for the first matching node
    main_node = matching_nodes[0]
    neighbors = list(graph.neighbors(main_node))

    if not neighbors:
        return f"Found entity '{main_node}', but it has no direct connections in the graph."

    result_str = f"Found entity '{main_node}' in the knowledge graph. It is connected to: {', '.join(neighbors)}."
    return result_str


def save_graph_visualization(graph: nx.Graph, output_dir: str):
    """Saves an interactive HTML visualization of the graph with proper UTF-8 encoding."""
    if not graph:
        return None

    path = os.path.join(output_dir, "knowledge_graph.html")

    try:
        # Create the network visualization
        nt = Network(notebook=True, cdn_resources='in_line', height="600px", width="100%")
        nt.from_nx(graph)

        # Generate HTML content and save with UTF-8 encoding
        html_content = nt.generate_html()

        # Write with explicit UTF-8 encoding to avoid charmap errors
        with open(path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        print(f"✅ Knowledge Graph visualization saved to {path}")
        return path

    except Exception as e:
        print(f"❌ Error saving knowledge graph visualization: {e}")
        # Fallback: try to save a simple text representation
        try:
            fallback_path = os.path.join(output_dir, "knowledge_graph.txt")
            with open(fallback_path, 'w', encoding='utf-8') as f:
                f.write(f"Knowledge Graph Summary\n")
                f.write(f"Nodes: {graph.number_of_nodes()}\n")
                f.write(f"Edges: {graph.number_of_edges()}\n\n")
                f.write("Node connections:\n")
                for node in list(graph.nodes())[:20]:  # Show first 20 nodes
                    neighbors = list(graph.neighbors(node))
                    if neighbors:
                        f.write(f"{node}: {', '.join(neighbors[:5])}\n")  # Show first 5 neighbors
            print(f"✅ Fallback graph summary saved to {fallback_path}")
            return fallback_path
        except Exception as fallback_error:
            print(f"❌ Fallback save also failed: {fallback_error}")
            return None
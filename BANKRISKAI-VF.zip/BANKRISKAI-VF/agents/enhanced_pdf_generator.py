# agents/enhanced_pdf_generator.py - FIXED VERSION
"""
Production-Ready Credit Risk Assessment PDF Generator
==================================================

A comprehensive PDF generation system specifically designed for banking risk assessment
reports with full markdown processing, visualization integration, and regulatory compliance.
"""

import os
import re
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.colors import (
    white,
    gray,
    HexColor
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak,
    KeepTogether
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class BankingColors:
    """Professional banking color scheme"""
    PRIMARY = HexColor('#1B4F72')  # Navy blue
    SECONDARY = HexColor('#2E86AB')  # Corporate blue
    SUCCESS = HexColor('#138D75')  # Approval green
    WARNING = HexColor('#D68910')  # Warning orange
    DANGER = HexColor('#C0392B')  # Rejection red
    TEXT = HexColor('#2C3E50')  # Dark text
    LIGHT_BG = HexColor('#F8F9FA')  # Light background
    BORDER = HexColor('#BDC3C7')  # Border color


class MarkdownToPDFConverter:
    """Converts markdown text to PDF-compatible elements"""

    def __init__(self):
        self.styles = self._create_styles()

    def _create_styles(self) -> Dict:
        """Create comprehensive PDF styles"""
        base_styles = getSampleStyleSheet()

        styles = {
            'Title': ParagraphStyle(
                'BankTitle',
                parent=base_styles['Title'],
                fontSize=20,
                textColor=BankingColors.PRIMARY,
                spaceAfter=24,
                alignment=TA_CENTER,
                fontName='Helvetica-Bold'
            ),
            'Heading1': ParagraphStyle(
                'BankHeading1',
                parent=base_styles['Heading1'],
                fontSize=16,
                textColor=BankingColors.PRIMARY,
                spaceAfter=18,
                spaceBefore=24,
                fontName='Helvetica-Bold',
                borderWidth=2,
                borderColor=BankingColors.PRIMARY,
                borderPadding=8,
                backColor=BankingColors.LIGHT_BG
            ),
            'Heading2': ParagraphStyle(
                'BankHeading2',
                parent=base_styles['Heading2'],
                fontSize=14,
                textColor=BankingColors.TEXT,
                spaceAfter=12,
                spaceBefore=18,
                fontName='Helvetica-Bold'
            ),
            'Heading3': ParagraphStyle(
                'BankHeading3',
                parent=base_styles['Normal'],
                fontSize=12,
                textColor=BankingColors.TEXT,
                spaceAfter=8,
                spaceBefore=12,
                fontName='Helvetica-Bold'
            ),
            'Normal': ParagraphStyle(
                'BankNormal',
                parent=base_styles['Normal'],
                fontSize=10,
                textColor=BankingColors.TEXT,
                spaceAfter=8,
                alignment=TA_JUSTIFY,
                fontName='Helvetica'
            ),
            'Bold': ParagraphStyle(
                'BankBold',
                parent=base_styles['Normal'],
                fontSize=10,
                textColor=BankingColors.TEXT,
                spaceAfter=8,
                alignment=TA_JUSTIFY,
                fontName='Helvetica-Bold'
            ),
            'Bullet': ParagraphStyle(
                'BankBullet',
                parent=base_styles['Normal'],
                fontSize=10,
                textColor=BankingColors.TEXT,
                spaceAfter=4,
                leftIndent=20,
                bulletIndent=10,
                fontName='Helvetica'
            ),
            'ExecutiveSummary': ParagraphStyle(
                'ExecutiveSummary',
                parent=base_styles['Normal'],
                fontSize=11,
                textColor=BankingColors.TEXT,
                spaceAfter=12,
                alignment=TA_JUSTIFY,
                fontName='Helvetica',
                borderWidth=1,
                borderColor=BankingColors.BORDER,
                borderPadding=12,
                backColor=BankingColors.LIGHT_BG
            ),
            'Approved': ParagraphStyle(
                'Approved',
                parent=base_styles['Normal'],
                fontSize=12,
                textColor=white,
                spaceAfter=15,
                alignment=TA_CENTER,
                fontName='Helvetica-Bold',
                borderWidth=2,
                borderColor=BankingColors.SUCCESS,
                borderPadding=10,
                backColor=BankingColors.SUCCESS
            ),
            'Warning': ParagraphStyle(
                'Warning',
                parent=base_styles['Normal'],
                fontSize=12,
                textColor=white,
                spaceAfter=15,
                alignment=TA_CENTER,
                fontName='Helvetica-Bold',
                borderWidth=2,
                borderColor=BankingColors.WARNING,
                borderPadding=10,
                backColor=BankingColors.WARNING
            ),
            'Rejected': ParagraphStyle(
                'Rejected',
                parent=base_styles['Normal'],
                fontSize=12,
                textColor=white,
                spaceAfter=15,
                alignment=TA_CENTER,
                fontName='Helvetica-Bold',
                borderWidth=2,
                borderColor=BankingColors.DANGER,
                borderPadding=10,
                backColor=BankingColors.DANGER
            ),
        }

        return styles

    def parse_markdown_to_elements(self, markdown_text: str, artifact_paths: Dict) -> List:
        """Parse markdown text and convert to PDF elements"""
        elements = []
        lines = markdown_text.split('\n')

        i = 0
        while i < len(lines):
            line = lines[i].strip()

            if not line:
                i += 1
                continue

            # Handle headers
            if line.startswith('#'):
                elements.extend(self._process_header(line))

            # Handle bold text blocks
            elif line.startswith('**') and line.endswith('**'):
                elements.append(Paragraph(line[2:-2], self.styles['Bold']))
                elements.append(Spacer(1, 6))

            # Handle bullet points
            elif line.startswith('- ') or line.startswith('• '):
                bullet_lines = []
                while i < len(lines) and (lines[i].strip().startswith('- ') or lines[i].strip().startswith('• ')):
                    bullet_lines.append(lines[i].strip()[2:])
                    i += 1
                i -= 1

                for bullet in bullet_lines:
                    elements.append(Paragraph(f"• {bullet}", self.styles['Bullet']))
                elements.append(Spacer(1, 8))

            # Handle analyze_plot_image instructions
            elif 'analyze_plot_image' in line or 'Use `analyze_plot_image`' in line:
                # Extract the image path
                path_match = re.search(r'(?:on: |path: )(.+?)(?:\n|$)', line)
                if path_match:
                    image_path = path_match.group(1).strip()
                    elements.extend(self._add_visualization_with_analysis(image_path, artifact_paths))

            # Handle recommendations with special styling
            elif any(keyword in line.upper() for keyword in ['APPROVED', 'REJECTED', 'CONDITIONAL']):
                style = self._get_recommendation_style(line)
                elements.append(Paragraph(line, style))
                elements.append(Spacer(1, 12))

            # Handle regular paragraphs
            else:
                # Check if it's part of a multi-line paragraph
                paragraph_lines = [line]
                j = i + 1
                while j < len(lines) and lines[j].strip() and not lines[j].startswith('#') and not lines[j].startswith(
                        '-') and not lines[j].startswith('•'):
                    paragraph_lines.append(lines[j].strip())
                    j += 1

                paragraph_text = ' '.join(paragraph_lines)
                if paragraph_text:
                    elements.append(Paragraph(paragraph_text, self.styles['Normal']))
                    elements.append(Spacer(1, 8))

                i = j - 1

            i += 1

        return elements

    def _process_header(self, line: str) -> List:
        """Process header lines and return appropriate elements"""
        elements = []

        if line.startswith('####'):
            text = line[4:].strip()
            elements.append(Spacer(1, 8))
            elements.append(Paragraph(text, self.styles['Heading3']))
            elements.append(Spacer(1, 6))
        elif line.startswith('###'):
            text = line[3:].strip()
            elements.append(Spacer(1, 12))
            elements.append(Paragraph(text, self.styles['Heading2']))
            elements.append(Spacer(1, 8))
        elif line.startswith('##'):
            text = line[2:].strip()
            elements.append(Spacer(1, 18))
            elements.append(Paragraph(text, self.styles['Heading2']))
            elements.append(Spacer(1, 12))
        elif line.startswith('#'):
            text = line[1:].strip()
            elements.append(PageBreak())
            elements.append(Paragraph(text, self.styles['Heading1']))
            elements.append(Spacer(1, 15))

        return elements

    def _get_recommendation_style(self, text: str) -> ParagraphStyle:
        """Determine the appropriate style for recommendations"""
        text_upper = text.upper()
        if 'APPROVED' in text_upper and 'CONDITIONAL' not in text_upper:
            return self.styles['Approved']
        elif 'CONDITIONAL' in text_upper or 'WARNING' in text_upper:
            return self.styles['Warning']
        elif 'REJECTED' in text_upper or 'NOT APPROVED' in text_upper:
            return self.styles['Rejected']
        else:
            return self.styles['Bold']

    def _add_visualization_with_analysis(self, image_path: str, artifact_paths: Dict) -> List:
        """Add visualization with analysis"""
        elements = []

        # Clean and resolve the image path
        resolved_path = self._resolve_image_path(image_path, artifact_paths)

        if resolved_path and os.path.exists(resolved_path):
            try:
                # Add the image
                img = Image(resolved_path, width=7 * inch, height=5 * inch, kind='proportional')
                elements.append(KeepTogether([img]))
                elements.append(Spacer(1, 10))

                # Add caption
                filename = os.path.basename(resolved_path).lower()
                caption = self._generate_caption(filename)
                elements.append(Paragraph(f"<i>{caption}</i>", self.styles['Normal']))
                elements.append(Spacer(1, 15))

                # Add analysis
                analysis = self._generate_visualization_analysis(filename)
                elements.append(Paragraph(analysis, self.styles['Normal']))
                elements.append(Spacer(1, 20))

            except Exception as e:
                logger.warning(f"Could not add image {resolved_path}: {e}")
                elements.append(Paragraph(f"[Visualization not available: {os.path.basename(image_path)}]",
                                          self.styles['Normal']))
                elements.append(Spacer(1, 12))
        else:
            logger.warning(f"Image not found: {image_path}")
            elements.append(Paragraph(f"[Visualization not available: {os.path.basename(image_path)}]",
                                      self.styles['Normal']))
            elements.append(Spacer(1, 12))

        return elements

    def _resolve_image_path(self, image_path: str, artifact_paths: Dict) -> Optional[str]:
        """Robust image path resolution with multiple fallback strategies."""
        if not image_path or image_path == "N/A":
            return None

        # Clean the path
        cleaned_path = image_path.replace('`', '').replace('"', '').replace("'", "").strip()

        # Strategy 1: Direct path exists
        if os.path.exists(cleaned_path):
            return cleaned_path

        # Strategy 2: Extract filename and match with artifact paths
        filename = os.path.basename(cleaned_path).lower()

        # Common filename patterns mapping
        filename_patterns = {
            'roc_curve': ['roc', 'auc', 'curve'],
            'confusion_matrix': ['confusion', 'matrix'],
            'shap_summary': ['shap', 'feature', 'importance'],
            'feature_importance': ['feature', 'importance'],
            'precision_recall': ['precision', 'recall']
        }

        # Try exact filename match first
        for key, path in artifact_paths.items():
            if path and isinstance(path, str):
                if filename in os.path.basename(path).lower():
                    return path

        # Try pattern matching
        for key, path in artifact_paths.items():
            if path and isinstance(path, str):
                path_basename = os.path.basename(path).lower()
                # Check if this path matches any known pattern
                for pattern_key, patterns in filename_patterns.items():
                    if all(pattern in path_basename for pattern in patterns):
                        # Check if the requested image matches this pattern
                        if any(pattern in filename for pattern in patterns):
                            return path

        # Strategy 3: Try key-based lookup
        if cleaned_path in artifact_paths and artifact_paths[cleaned_path]:
            return str(artifact_paths[cleaned_path])

        # Strategy 4: Try partial key matching
        for key, path in artifact_paths.items():
            if key and path and cleaned_path in key:
                return str(path)

        # Strategy 5: Search in output directory
        output_dir = os.path.dirname(list(artifact_paths.values())[0]) if artifact_paths else None
        if output_dir:
            for file in os.listdir(output_dir):
                if filename in file.lower():
                    return os.path.join(output_dir, file)

        print(f"⚠️ Could not resolve image path: {image_path}")
        return None

    def _generate_caption(self, filename: str) -> str:
        """Generate appropriate caption for visualization"""
        captions = {
            'roc_curve': 'Figure: ROC Curve Analysis - Model Discriminatory Power Assessment',
            'confusion_matrix': 'Figure: Confusion Matrix - Classification Performance Evaluation',
            'shap_summary': 'Figure: SHAP Feature Importance - Model Interpretability Analysis',
            'shap_feature_importance': 'Figure: SHAP Feature Importance - Risk Driver Analysis',
            'feature_importance': 'Figure: Feature Importance - Key Predictive Factors',
            'precision_recall': 'Figure: Precision-Recall Curve - Threshold Optimization'
        }

        for key, caption in captions.items():
            if key in filename:
                return caption

        return f'Figure: {filename.replace("_", " ").title()} Analysis'

    def _generate_visualization_analysis(self, filename: str) -> str:
        """Generate detailed analysis for visualization"""

        if 'roc_curve' in filename:
            return """<b>ROC Curve Analysis:</b><br/>
The ROC (Receiver Operating Characteristic) curve demonstrates the model's discriminatory power across all classification thresholds. 
A curve closer to the top-left corner indicates superior performance, with the Area Under the Curve (AUC) quantifying overall effectiveness. 
In credit risk assessment, this metric is crucial for regulatory compliance and risk management decision-making."""

        elif 'confusion_matrix' in filename:
            return """<b>Confusion Matrix Analysis:</b><br/>
The confusion matrix provides a detailed breakdown of classification performance, showing both correct predictions and error types. 
In banking contexts, false negatives (approving risky loans) typically carry higher costs than false positives (rejecting good loans). 
This visualization enables optimization of decision thresholds based on business risk tolerance."""

        elif 'shap' in filename:
            return """<b>SHAP Feature Importance Analysis:</b><br/>
SHAP (SHapley Additive exPlanations) values provide model interpretability required for regulatory compliance and risk management. 
This analysis identifies the key drivers of credit risk predictions and enables transparent explanation of model decisions to 
regulators, auditors, and business stakeholders. Features are ranked by their average impact on model predictions."""

        elif 'feature_importance' in filename:
            return """<b>Feature Importance Analysis:</b><br/>
This analysis ranks input features by their contribution to model predictions, identifying the most significant risk factors 
in the credit assessment process. Understanding feature importance is essential for model validation, regulatory reporting, 
and business strategy development in risk management."""

        elif 'precision_recall' in filename:
            return """<b>Precision-Recall Analysis:</b><br/>
The precision-recall curve illustrates the trade-off between precision (accuracy of positive predictions) and recall 
(coverage of actual positives). This analysis is particularly valuable for optimizing decision thresholds in imbalanced 
datasets and aligning model performance with business objectives and risk tolerance."""

        else:
            return """<b>Performance Analysis:</b><br/>
This visualization provides insights into model performance characteristics that should be evaluated in conjunction 
with other performance metrics and business requirements for comprehensive risk assessment."""


class EnhancedPDFReportGenerator:
    """Enhanced PDF generator for banking risk assessment reports"""

    def __init__(self):
        self.converter = MarkdownToPDFConverter()
        self.page_size = A4
        self.margins = {
            'top': 1.2 * inch,
            'bottom': 1 * inch,
            'left': 0.8 * inch,
            'right': 0.8 * inch
        }

    def _create_header_footer(self, canvas_obj, doc):
        """Create professional header and footer"""
        page_width, page_height = self.page_size
        canvas_obj.saveState()

        # Header
        canvas_obj.setStrokeColor(BankingColors.PRIMARY)
        canvas_obj.setLineWidth(3)
        canvas_obj.line(
            self.margins['left'],
            page_height - self.margins['top'] + 20,
            page_width - self.margins['right'],
            page_height - self.margins['top'] + 20
        )

        # Classification
        canvas_obj.setFont("Helvetica-Bold", 10)
        canvas_obj.setFillColor(BankingColors.DANGER)
        canvas_obj.drawCentredString(
            page_width / 2,
            page_height - self.margins['top'] + 30,
            "CONFIDENTIAL - INTERNAL USE ONLY"
        )

        # Footer
        canvas_obj.setFont("Helvetica", 8)
        canvas_obj.setFillColor(gray)

        # Page number
        page_num = canvas_obj.getPageNumber()
        canvas_obj.drawRightString(
            page_width - self.margins['right'],
            self.margins['bottom'] - 30,
            f"Page {page_num}"
        )

        # Department
        canvas_obj.drawString(
            self.margins['left'],
            self.margins['bottom'] - 30,
            "Risk Management Department"
        )

        # Timestamp
        canvas_obj.drawCentredString(
            page_width / 2,
            self.margins['bottom'] - 30,
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M UTC')}"
        )

        canvas_obj.restoreState()

    def _create_cover_page(self, context_dict: Dict) -> List:
        """Create professional cover page"""
        elements = []

        # Title
        elements.append(Spacer(1, 2 * inch))
        elements.append(Paragraph("CREDIT RISK MODEL", self.converter.styles['Title']))
        elements.append(Paragraph("ASSESSMENT REPORT", self.converter.styles['Title']))
        elements.append(Spacer(1, 0.5 * inch))

        # Subtitle
        elements.append(Paragraph("Comprehensive Analysis & Regulatory Compliance Review",
                                  self.converter.styles['Heading2']))
        elements.append(Spacer(1, 1 * inch))

        # Model information
        model_info = context_dict.get('model_info', {})
        model_name = model_info.get('model_name', 'Unknown Model')
        performance = model_info.get('performance', {})
        roc_auc = performance.get('roc_auc', 0.0)

        info_text = f"""
        <b>Model:</b> {model_name}<br/>
        <b>Performance (ROC-AUC):</b> {roc_auc:.4f}<br/>
        <b>Assessment Date:</b> {datetime.now().strftime('%B %d, %Y')}<br/>
        <b>Report Type:</b> Executive Risk Assessment<br/>
        """

        elements.append(Paragraph(info_text, self.converter.styles['ExecutiveSummary']))
        elements.append(Spacer(1, 1 * inch))

        # Performance classification
        if roc_auc >= 0.90:
            classification = "EXCELLENT PERFORMANCE"
            style = self.converter.styles['Approved']
        elif roc_auc >= 0.80:
            classification = "GOOD PERFORMANCE"
            style = self.converter.styles['Approved']
        elif roc_auc >= 0.70:
            classification = "ACCEPTABLE PERFORMANCE"
            style = self.converter.styles['Warning']
        else:
            classification = "INSUFFICIENT PERFORMANCE"
            style = self.converter.styles['Rejected']

        elements.append(Paragraph(f"PERFORMANCE CLASSIFICATION: {classification}", style))
        elements.append(PageBreak())

        return elements

    def generate_pdf_report(self, report_text: str, context_dict: Dict, output_path: str) -> str:
        """Generate comprehensive PDF report"""
        try:
            # Ensure output directory exists
            os.makedirs(os.path.dirname(output_path), exist_ok=True)

            # Create document
            doc = SimpleDocTemplate(
                output_path,
                pagesize=self.page_size,
                rightMargin=self.margins['right'],
                leftMargin=self.margins['left'],
                topMargin=self.margins['top'],
                bottomMargin=self.margins['bottom']
            )

            story = []

            # Add cover page
            try:
                story.extend(self._create_cover_page(context_dict))
            except Exception as e:
                logger.warning(f"Cover page creation failed: {e}")
                # Add simple title instead
                story.append(Paragraph("Credit Risk Model Assessment Report", self.converter.styles['Title']))
                story.append(PageBreak())

            # Convert markdown report to PDF elements
            try:
                artifact_paths = context_dict.get('artifact_paths', {})
                story.extend(self.converter.parse_markdown_to_elements(report_text, artifact_paths))
            except Exception as e:
                logger.error(f"Markdown conversion failed: {e}")
                # Add raw text as fallback
                story.append(Paragraph("Report content processing failed. Raw report follows:",
                                     self.converter.styles['Heading2']))
                story.append(Paragraph(report_text[:2000], self.converter.styles['Normal']))

            # Add disclaimer
            disclaimer = """
            <b>IMPORTANT DISCLAIMER:</b><br/>
            This report is generated by an automated risk assessment system and is intended for internal use only. 
            All model deployments must be approved by the Risk Management Committee and comply with applicable 
            banking regulations. Model performance should be continuously monitored and validated according to 
            established governance procedures.
            """

            story.append(Spacer(1, 30))
            story.append(Paragraph(disclaimer, self.converter.styles['Normal']))

            # Build PDF with enhanced error handling
            doc.build(story, onFirstPage=self._create_header_footer, onLaterPages=self._create_header_footer)

            logger.info(f"PDF report generated successfully: {output_path}")
            return output_path

        except Exception as e:
            logger.error(f"Error generating PDF report: {e}")
            import traceback
            traceback.print_exc()
            return None


def create_professional_pdf_report(report_text: str, artifacts: Dict, output_dir: str) -> Optional[str]:
    """
    Main function to create professional PDF report
    """
    try:
        # Prepare context dictionary
        context_dict = {
            'model_info': {
                'model_name': artifacts.get('best_model_name', 'Unknown Model'),
                'performance': {
                    'roc_auc': artifacts.get('score_val', 0.0)
                }
            },
            'artifact_paths': artifacts
        }

        # Generate PDF filename
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"credit_risk_assessment_{timestamp}.pdf"
        output_path = os.path.join(output_dir, filename)

        # Create PDF generator and generate report
        generator = EnhancedPDFReportGenerator()
        result_path = generator.generate_pdf_report(report_text, context_dict, output_path)

        return result_path

    except Exception as e:
        logger.error(f"Failed to create PDF report: {e}")
        return None
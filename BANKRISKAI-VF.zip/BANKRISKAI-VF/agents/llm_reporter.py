# agents/llm_reporter.py
from agents.rag_agent import initialize_agent, initialize_llm


def format_context_for_prompt(context_dict: dict) -> str:
    """Format context data into a readable string for the LLM prompt."""
    model_info = context_dict.get('model_info', {})
    performance = model_info.get('performance', {})
    shap_data = context_dict.get('shap_data', {})

    # Extract performance metrics with defaults
    roc_auc = performance.get('roc_auc', 0.0)
    accuracy = performance.get('accuracy', 0.0)
    precision = performance.get('precision', 0.0)
    recall = performance.get('recall', 0.0)
    f1 = performance.get('f1', 0.0)

    # Format top features from SHAP analysis
    top_features = (shap_data or {}).get("top_features", [])
    if top_features:
        top_features_str = "\n".join([
            f"- **{f.get('feature', 'N/A')}**: Average Impact on Prediction (Importance: {f.get('importance', 0.0):.4f})"
            for f in top_features[:10]  # Limit to top 10 features
        ])
    else:
        top_features_str = "- SHAP analysis not available or failed."

    report_str = f"""
**Model Information:**
- **Best Model:** `{model_info.get('model_name', 'N/A')}`
- **ROC-AUC Score:** {roc_auc:.4f}
- **Accuracy:** {accuracy:.4f}

**Key Performance Indicators:**
- **Precision:** {precision:.4f} (Of predicted positives, how many were correct)
- **Recall:** {recall:.4f} (Of actual positives, how many were caught)
- **F1-Score:** {f1:.4f} (Harmonic mean of precision and recall)

**Key Drivers of Risk (from SHAP Analysis):**
{top_features_str}

**Model Performance Context:**
- ROC-AUC > 0.7: Acceptable performance
- ROC-AUC > 0.8: Good performance  
- ROC-AUC > 0.9: Excellent performance
- Current Score: {roc_auc:.4f}
"""
    return report_str.strip()


def generate_llm_enhanced_report_from_context(context_dict: dict) -> str:
    """Generate a comprehensive report using the LLM agent with RAG capabilities."""

    try:
        # Initialize LLM and agent
        llm = initialize_llm()
        vectorstore = context_dict.get("vectorstore")
        knowledge_graph = context_dict.get("knowledge_graph")

        agent_executor = initialize_agent(llm, vectorstore, knowledge_graph)

        # Format context for the prompt
        context_str = format_context_for_prompt(context_dict)

        # Get artifact paths - Handle None values properly
        artifact_paths = context_dict.get("artifact_paths", {})
        roc_path = artifact_paths.get("roc_curve", "N/A")
        cm_path = artifact_paths.get("confusion_matrix", "N/A")
        shap_path = artifact_paths.get("shap_summary_path", "N/A")
        fi_plot_path = artifact_paths.get("feature_importance_plot", "N/A")
        pr_path = artifact_paths.get("precision_recall", "N/A")
        kg_viz_path = artifact_paths.get("knowledge_graph_viz", "N/A")

        # Ensure all paths are strings and handle None values
        roc_path = str(roc_path) if roc_path else "N/A"
        cm_path = str(cm_path) if cm_path else "N/A"
        shap_path = str(shap_path) if shap_path else "N/A"
        fi_plot_path = str(fi_plot_path) if fi_plot_path else "N/A"
        pr_path = str(pr_path) if pr_path else "N/A"
        kg_viz_path = str(kg_viz_path) if kg_viz_path else "N/A"

        # Extract performance for decision logic
        performance = context_dict.get('model_info', {}).get('performance', {})
        roc_auc = performance.get('roc_auc', 0.0)

        prompt = f"""
You are an experienced Chief Risk Officer creating a comprehensive executive report for a bank's credit risk model. 
Your report will be converted to a professional PDF, so follow markdown formatting precisely.

**CRITICAL FORMATTING REQUIREMENTS:**
1. Use proper markdown headers (# ## ### ####)
2. Use **bold** for important terms
3. Use - for bullet points
4. Keep sections well-organized and professional
5. When referencing visualizations, use the exact format: "Use `analyze_plot_image` on: [path]"

**REPORT STRUCTURE TO FOLLOW EXACTLY:**

# Comprehensive Credit Risk Model Assessment & Regulatory Compliance Review

## 1. Executive Summary

### 1.1 Model Overview
- **Model Name:** {context_dict.get('model_info', {}).get('model_name', 'Unknown Model')}
- **Primary Use Case:** Credit risk assessment and lending decision support
- **Overall Performance:** ROC-AUC of {roc_auc:.4f}

### 1.2 Key Findings
Provide 2-3 key findings about model performance and risk drivers.

### 1.3 Final Recommendation
Based on ROC-AUC of {roc_auc:.4f}, provide clear deployment recommendation:
- If ≥0.90: "**APPROVED FOR PRODUCTION DEPLOYMENT**"
- If ≥0.80: "**APPROVED WITH STANDARD MONITORING**"  
- If ≥0.70: "**CONDITIONAL APPROVAL - REQUIRES ENHANCEMENT**"
- If <0.70: "**REJECTED - MODEL REDEVELOPMENT REQUIRED**"

## 2. Quantitative Model Performance Analysis

### 2.1 Discriminatory Power Assessment (ROC Analysis)
Use `analyze_plot_image` on: {roc_path}

**ROC-AUC Score:** {roc_auc:.4f}

Provide business interpretation of this score for banking decisions.

### 2.2 Classification Performance Evaluation (Confusion Matrix)
Use `analyze_plot_image` on: {cm_path}

**Performance Metrics:**
- **Precision:** {performance.get('precision', 0.0):.4f}
- **Recall:** {performance.get('recall', 0.0):.4f}
- **F1-Score:** {performance.get('f1', 0.0):.4f}

Explain the business impact of false positives vs false negatives in banking.

### 2.3 Precision-Recall Analysis
{"Use `analyze_plot_image` on: " + pr_path if pr_path != "N/A" else "Precision-Recall analysis not available for this model."}

## 3. Model Interpretability & Risk Driver Analysis

### 3.1 SHAP Feature Importance Analysis
Use `analyze_plot_image` on: {shap_path}

### 3.2 Key Risk Drivers
List and explain the top 5 features from SHAP analysis with business context:

{"Based on SHAP analysis, the primary risk drivers are:" if context_dict.get('shap_data', {}).get('top_features') else "SHAP feature importance analysis was not available for this assessment."}

### 3.3 Feature Importance Analysis  
{"Use `analyze_plot_image` on: " + fi_plot_path if fi_plot_path != "N/A" else "Standard feature importance analysis not available."}

## 4. Regulatory Compliance Assessment

### 4.1 Basel III Framework Alignment

Use your tools to search for regulatory information and provide assessment of:

#### 4.1.1 Pillar 1 - Minimum Capital Requirements
Use `search_regulatory_documents` to find information about credit risk requirements.

#### 4.1.2 Pillar 2 - Supervisory Review Process
Use `search_regulatory_documents` to find information about internal assessment requirements.

#### 4.1.3 Pillar 3 - Market Discipline
Assess model transparency and disclosure capabilities.

### 4.2 Model Governance Requirements
Discuss validation, monitoring, and governance requirements.

## 5. Risk Assessment & Strategic Recommendations

### 5.1 Model Strengths
List 3-4 key advantages of this model.

### 5.2 Areas for Improvement  
List 2-3 areas where the model could be enhanced.

### 5.3 Implementation Roadmap

#### 5.3.1 Deployment Decision
Restate your final recommendation with clear reasoning.

#### 5.3.2 Next Steps
Provide specific, actionable next steps:
1. [First action]
2. [Second action]  
3. [Third action]

#### 5.3.3 Monitoring and Success Metrics
Define specific KPIs and monitoring requirements.

## 6. Conclusion

Provide a concise summary and final assessment.

---

**Model Performance Summary:**
{context_str}

**Available Analysis Artifacts:**
- ROC Curve: {roc_path}
- Confusion Matrix: {cm_path}
- SHAP Analysis: {shap_path}
- Feature Importance: {fi_plot_path}
- Precision-Recall: {pr_path}

**IMPORTANT INSTRUCTIONS:**
1. Use your available tools (search_regulatory_documents, query_risk_knowledge_graph, analyze_plot_image) strategically
2. Provide specific, actionable insights rather than generic statements
3. Focus on business impact and regulatory compliance
4. Use professional banking terminology
5. Ensure all visualization references use the exact format: "Use `analyze_plot_image` on: [path]"
6. Provide clear, decisive recommendations based on performance metrics

Generate the comprehensive analysis now, following this structure exactly.
"""

        print("🧠 Invoking enhanced agent to generate comprehensive report...")
        response = agent_executor.invoke({
            "input": prompt,
            "chat_history": []
        })

        output = response.get("output", "").strip()
        if not output:
            raise ValueError("Agent returned empty output")

        print("✅ Agent response received successfully.")
        return output

    except Exception as e:
        print(f"❌ Error during agent report generation: {e}")
        import traceback
        traceback.print_exc()

        # Return a structured fallback report instead of just the error message
        return generate_structured_fallback_report(context_dict, str(e))


def generate_structured_fallback_report(context_dict: dict, error_msg: str) -> str:
    """Generate a well-structured fallback report when LLM agent fails."""

    model_info = context_dict.get('model_info', {})
    performance = model_info.get('performance', {})
    artifact_paths = context_dict.get('artifact_paths', {})

    model_name = model_info.get('model_name', 'Unknown Model')
    roc_auc = performance.get('roc_auc', 0.0)
    accuracy = performance.get('accuracy', 0.0)
    precision = performance.get('precision', 0.0)
    recall = performance.get('recall', 0.0)
    f1 = performance.get('f1', 0.0)

    # Determine performance level and recommendation
    if roc_auc >= 0.90:
        perf_level = "Excellent"
        recommendation = "**APPROVED FOR PRODUCTION DEPLOYMENT**"
    elif roc_auc >= 0.80:
        perf_level = "Good"
        recommendation = "**APPROVED WITH STANDARD MONITORING**"
    elif roc_auc >= 0.70:
        perf_level = "Acceptable"
        recommendation = "**CONDITIONAL APPROVAL - REQUIRES ENHANCEMENT**"
    else:
        perf_level = "Insufficient"
        recommendation = "**REJECTED - MODEL REDEVELOPMENT REQUIRED**"

    fallback_report = f"""# Credit Risk Model Assessment Report

## 1. Executive Summary

### 1.1 Model Overview
- **Model Name:** {model_name}
- **Primary Use Case:** Credit risk assessment and lending decision support
- **Overall Performance:** ROC-AUC of {roc_auc:.4f}

### 1.2 Key Findings
- **Performance Classification:** {perf_level} discriminatory power
- **Technical Assessment:** Automated analysis system encountered limitations
- **Risk Assessment:** Model evaluation completed with available metrics

### 1.3 Final Recommendation
{recommendation}

## 2. Quantitative Model Performance Analysis

### 2.1 Discriminatory Power Assessment (ROC Analysis)
Use `analyze_plot_image` on: {artifact_paths.get('roc_curve', 'N/A')}

**ROC-AUC Score:** {roc_auc:.4f}

The model demonstrates {perf_level.lower()} discriminatory power with an AUC score of {roc_auc:.4f}, indicating {"strong" if roc_auc >= 0.8 else "moderate" if roc_auc >= 0.7 else "insufficient"} ability to distinguish between creditworthy and high-risk applicants.

### 2.2 Classification Performance Evaluation (Confusion Matrix)
Use `analyze_plot_image` on: {artifact_paths.get('confusion_matrix', 'N/A')}

**Performance Metrics:**
- **Precision:** {precision:.4f}
- **Recall:** {recall:.4f}
- **F1-Score:** {f1:.4f}

### 2.3 Precision-Recall Analysis
{"Use `analyze_plot_image` on: " + artifact_paths.get('precision_recall', 'N/A') if artifact_paths.get('precision_recall') != 'N/A' else "Precision-Recall analysis not available for this model."}

## 3. Model Interpretability & Risk Driver Analysis

### 3.1 SHAP Feature Importance Analysis
Use `analyze_plot_image` on: {artifact_paths.get('shap_summary_path', 'N/A')}

### 3.2 Key Risk Drivers
{"SHAP analysis provides insights into the primary factors driving risk predictions in this model." if artifact_paths.get('shap_summary_path') != 'N/A' else "SHAP feature importance analysis was not available for this assessment."}

### 3.3 Feature Importance Analysis
{"Use `analyze_plot_image` on: " + artifact_paths.get('feature_importance_plot', 'N/A') if artifact_paths.get('feature_importance_plot') != 'N/A' else "Standard feature importance analysis not available."}

## 4. Regulatory Compliance Assessment

### 4.1 Basel III Framework Alignment

#### 4.1.1 Pillar 1 - Minimum Capital Requirements
The model supports quantitative risk assessment required for capital adequacy calculations and RWA determination.

#### 4.1.2 Pillar 2 - Supervisory Review Process  
Model interpretability features support internal capital adequacy assessment processes and supervisory review requirements.

#### 4.1.3 Pillar 3 - Market Discipline
Transparent model documentation and explanation capabilities support regulatory disclosure requirements.

### 4.2 Model Governance Requirements
- Independent validation and ongoing monitoring required
- Regular performance review and recalibration protocols needed
- Comprehensive documentation and audit trail maintenance essential

## 5. Risk Assessment & Strategic Recommendations

### 5.1 Model Strengths"""

    if roc_auc >= 0.8:
        fallback_report += """
- Strong discriminatory power suitable for risk assessment
- Robust performance metrics indicating reliable predictions
- Interpretability features supporting regulatory compliance
- Scalable architecture for production deployment"""
    elif roc_auc >= 0.7:
        fallback_report += """
- Acceptable baseline performance for risk assessment
- Basic interpretability framework in place
- Foundation for further enhancement and development
- Suitable for conditional deployment with monitoring"""
    else:
        fallback_report += """
- Basic modeling framework established
- Data processing and feature engineering capabilities
- Potential for significant improvement through enhancement
- Learning foundation for advanced model development"""

    fallback_report += """

### 5.2 Areas for Improvement"""

    if roc_auc >= 0.8:
        fallback_report += """
- Enhanced monitoring and drift detection capabilities
- Stress testing under adverse economic conditions
- Feature stability validation across market cycles
- Integration optimization with existing systems"""
    elif roc_auc >= 0.7:
        fallback_report += """
- Feature engineering to improve discriminatory power
- Alternative modeling techniques exploration
- Enhanced data quality and preprocessing
- Comprehensive validation and backtesting"""
    else:
        fallback_report += """
- Fundamental model architecture redesign
- Comprehensive feature selection and engineering
- Advanced modeling methodologies implementation
- Enhanced data collection and quality improvement"""

    fallback_report += f"""

### 5.3 Implementation Roadmap

#### 5.3.1 Deployment Decision
{recommendation}

Based on ROC-AUC performance of {roc_auc:.4f}, this model {"meets" if roc_auc >= 0.7 else "does not meet"} minimum performance thresholds for {"conditional " if roc_auc < 0.8 else ""}production consideration.

#### 5.3.2 Next Steps"""

    if roc_auc >= 0.8:
        fallback_report += """
1. Conduct comprehensive regulatory compliance review
2. Implement production monitoring and governance framework
3. Execute shadow deployment testing phase
4. Establish ongoing performance monitoring protocols"""
    elif roc_auc >= 0.7:
        fallback_report += """
1. Enhance model performance through advanced techniques
2. Conduct extensive validation and stress testing
3. Implement conditional deployment with strict monitoring
4. Develop improvement roadmap for full deployment"""
    else:
        fallback_report += """
1. Initiate comprehensive model redevelopment project
2. Conduct thorough data quality and availability assessment
3. Explore alternative modeling approaches and methodologies
4. Establish enhanced development and validation framework"""

    fallback_report += f"""

#### 5.3.3 Monitoring and Success Metrics
- **Primary KPI:** Maintain ROC-AUC performance above {"0.85" if roc_auc >= 0.8 else "0.75"}
- **Secondary KPIs:** Precision, recall, and F1-score stability monitoring
- **Business Metrics:** Portfolio performance and default prediction accuracy
- **Regulatory Compliance:** Model documentation and interpretability standards

## 6. Conclusion

This assessment provides a {"comprehensive" if roc_auc >= 0.7 else "preliminary"} evaluation of the credit risk model based on available quantitative metrics and performance indicators. The model demonstrates {perf_level.lower()} performance characteristics {"suitable for" if roc_auc >= 0.7 else "requiring enhancement before"} deployment in a production banking environment.

**Final Assessment:** {recommendation}

---

**Technical Note:** This report was generated with limited system capabilities due to technical constraints: {error_msg}

A complete assessment including full regulatory analysis and detailed interpretations should be conducted once all system components are fully operational.
"""

    return fallback_report
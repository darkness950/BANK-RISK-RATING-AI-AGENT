# agents/__init__.py

# Import all the main components to make them easily accessible
from .mcp import ModelContext, ModelPerformance
from .mcp_controller import MCPController
from .resilience_manager import ResilienceManager
from .document_retriever import load_documents, create_vectorstore, load_dataset_documents, load_regulatory_documents
from .rag_agent import initialize_llm, initialize_agent, search_documents_func, get_enhanced_image_analysis
from .model_selector import run_automl_pipeline, preprocess_dataframe, get_problem_type, hash_dataset
from .report_generator import generate_report, extract_performance_metrics_from_classification_report
from .graph_rag import build_knowledge_graph, query_knowledge_graph, save_graph_visualization, extract_entities_and_relations
from .llm_reporter import generate_llm_enhanced_report_from_context, generate_structured_fallback_report, format_context_for_prompt

# Optional: If you have enhanced_pdf_generator
try:
    from .enhanced_pdf_generator import create_professional_pdf_report, EnhancedPDFReportGenerator, MarkdownToPDFConverter
except ImportError:
    pass

# Define what gets imported with "from agents import *"
__all__ = [
    'ModelContext',
    'ModelPerformance',
    'MCPController',
    'ResilienceManager',
    'load_documents',
    'create_vectorstore',
    'load_dataset_documents',
    'load_regulatory_documents',
    'initialize_llm',
    'initialize_agent',
    'search_documents_func',
    'get_enhanced_image_analysis',
    'run_automl_pipeline',
    'preprocess_dataframe',
    'get_problem_type',
    'hash_dataset',
    'generate_report',
    'extract_performance_metrics_from_classification_report',
    'build_knowledge_graph',
    'query_knowledge_graph',
    'save_graph_visualization',
    'extract_entities_and_relations',
    'generate_llm_enhanced_report_from_context',
    'generate_structured_fallback_report',
    'format_context_for_prompt'
]

# Package metadata
__version__ = '1.0.0'
__author__ = 'AI Risk Analysis Team'
__description__ = 'Autonomous AI Risk Officer for banking risk assessment'
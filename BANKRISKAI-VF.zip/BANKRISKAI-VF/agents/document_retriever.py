# agents/document_retriever.py

import pandas as pd
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.docstore.document import Document
from langchain_community.document_loaders import PyPDFLoader
import os


# In document_retriever.py - ADD

def save_vectorstore(vectorstore, output_dir):
    """Save FAISS vectorstore to disk"""
    if vectorstore:
        vectorstore.save_local(os.path.join(output_dir, "vectorstore"))


def load_vectorstore(output_dir, embeddings):
    """Load FAISS vectorstore from disk"""
    vectorstore_path = os.path.join(output_dir, "vectorstore")
    if os.path.exists(vectorstore_path):
        return FAISS.load_local(vectorstore_path, embeddings)
    return None
def load_dataset_documents(filepath):
    df = pd.read_csv(filepath)
    # Convert all columns to string to avoid type errors during join
    df = df.astype(str)
    documents = [
        Document(
            page_content=", ".join(f"{col}: {row[col]}" for col in df.columns),
            metadata={"source": "dataset_row", "index": idx}
        )
        for idx, row in df.iterrows()
    ]
    print(f"✅ Loaded {len(documents)} dataset rows as documents.")
    return documents


def load_regulatory_documents():
    # Assuming the regulatory document is in the data directory
    pdf_path = "data/basel_iii.pdf"
    if not os.path.exists(pdf_path):
        print(f"⚠️ Warning: Regulatory document not found at {pdf_path}. Skipping.")
        return []

    loader = PyPDFLoader(pdf_path)
    pages = loader.load()
    for i, doc in enumerate(pages):
        doc.metadata["title"] = "Basel III"
        doc.metadata["page"] = i + 1
        doc.metadata["source"] = "basel_iii.pdf"
    print(f"✅ Loaded {len(pages)} regulatory documents from Basel III.")
    return pages


def load_documents(filepath):
    dataset_docs = load_dataset_documents(filepath)
    regulatory_docs = load_regulatory_documents()
    all_docs = dataset_docs + regulatory_docs
    print(f"📄 Total documents loaded: {len(all_docs)}")
    return all_docs


def create_vectorstore(documents):
    if not documents:
        print("⚠️ No documents to process. Skipping vectorstore creation.")
        return None
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = FAISS.from_documents(documents, embeddings)
    print(f"✅ Vectorstore created with {len(documents)} documents.")
    return vectorstore
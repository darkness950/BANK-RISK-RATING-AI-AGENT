# agents/mcp_controller.py
from agents import document_retriever, rag_agent, model_selector, report_generator, graph_rag
from agents.mcp import ModelContext, ModelPerformance
from agents.resilience_manager import ResilienceManager
import yaml
import os
import pandas as pd
import numpy as np
import json
import shutil


class MCPController:
    def __init__(self, dataset_path, target_column=None, config_path="mcp_config.yaml"):
        self.config = self._load_config(config_path)
        df = pd.read_csv(dataset_path)
        dataset_hash = model_selector.hash_dataset(df)
        output_dir = os.path.join("data/results", f"run_{dataset_hash}")
        os.makedirs(output_dir, exist_ok=True)

        self.context = ModelContext(
            dataset_path=dataset_path,
            target_column=target_column if target_column else df.columns[-1],
            output_dir=output_dir
        )

        # Initialize resilience manager
        self.resilience_manager = ResilienceManager(
            checkpoint_dir=os.path.join(output_dir, "checkpoints")
        )

        # Load any existing state
        saved_state = self.resilience_manager.load_latest_state()
        if saved_state:
            print(f"Loaded saved state from checkpoint")
            self._load_context_state(saved_state)

        print(f"Initialized MCP with Run ID: {self.context.run_id}")
        print(f"Output directory set to: {self.context.output_dir}")

    def _load_config(self, config_path):
        try:
            with open(config_path, "r") as f:
                return yaml.safe_load(f)
        except Exception as e:
            print(f"Failed to load config: {e}")
            return {}

    def _save_context_state(self):
        """Save current context state for resilience"""
        return {
            'run_id': self.context.run_id,
            'dataset_path': self.context.dataset_path,
            'target_column': self.context.target_column,
            'output_dir': self.context.output_dir,
            'best_model_name': self.context.best_model_name,
            'performance': self.context.performance.model_dump() if hasattr(self.context.performance,
                                                                            'model_dump') else {},
            'artifact_paths': self.context.artifact_paths,
            'current_step': getattr(self, '_current_step', 'start')
        }

    def _load_context_state(self, state_data):
        """Load context state from saved data"""
        if not state_data:
            return

        # Restore basic attributes
        self.context.best_model_name = state_data.get('best_model_name')
        self.context.artifact_paths = state_data.get('artifact_paths', {})

        # Restore performance metrics
        perf_data = state_data.get('performance', {})
        if hasattr(self.context.performance, 'model_validate'):
            self.context.performance = ModelPerformance.model_validate(perf_data)
        else:
            self.context.performance = ModelPerformance(**perf_data)

        # Set current step for resumption
        self._current_step = state_data.get('current_step', 'start')

    def cleanup(self):
        """Cleanup resources"""
        print("Cleaning up resources...")
        self.resilience_manager.save_state(self._save_context_state())

    def _cleanup_checkpoints(self):
        """Clean up checkpoint files after successful completion"""
        checkpoint_dir = os.path.join(self.context.output_dir, "checkpoints")
        if os.path.exists(checkpoint_dir):
            shutil.rmtree(checkpoint_dir)
            print("Cleaned up checkpoint files")

    def run(self):
        """Orchestrates the complete pipeline with caching and resilience."""
        results_json_path = os.path.join(self.context.output_dir, "results.json")

        # Check if we have a completed run first
        if os.path.exists(results_json_path):
            print(f"Found cached results in {self.context.output_dir}. Loading from cache.")
            with open(results_json_path, 'r') as f:
                return json.load(f)

        # Check if we have a partial run to resume
        self._current_step = getattr(self, '_current_step', 'start')

        # Initialize variables
        vectorstore = None
        knowledge_graph = None

        try:
            # Step 1: Document Loading and RAG Setup
            if self._current_step in ['start', 'step1']:
                print("Step 1: Loading documents and setting up RAG...")
                self._current_step = 'step1'
                self.resilience_manager.save_state(self._save_context_state())

                documents = document_retriever.load_documents(self.context.dataset_path)
                vectorstore = document_retriever.create_vectorstore(documents)

                # Build knowledge graph with improved error handling
                knowledge_graph = graph_rag.build_knowledge_graph()
                if knowledge_graph:
                    print(
                        f"Knowledge graph created with {knowledge_graph.number_of_nodes()} nodes and {knowledge_graph.number_of_edges()} edges")
                    kg_viz_path = graph_rag.save_graph_visualization(knowledge_graph, self.context.output_dir)
                    if kg_viz_path:
                        self.context.artifact_paths["knowledge_graph_viz"] = kg_viz_path
                    else:
                        print("Knowledge graph visualization could not be created, but graph data is available")
                else:
                    print("Knowledge graph could not be built")

            # Step 2: AutoML Model Selection & Evaluation
            if self._current_step in ['step1', 'step2']:
                print("Step 2: Running AutoML pipeline...")
                self._current_step = 'step2'
                self.resilience_manager.save_state(self._save_context_state())

                automl_results = model_selector.run_automl_pipeline(
                    filepath=self.context.dataset_path,
                    target_column=self.context.target_column,
                    output_base_dir=os.path.dirname(self.context.output_dir),
                    config=self.config
                )

            # Step 3: Update context with results
            if self._current_step in ['step2', 'step3']:
                print("Step 3: Updating context with AutoML results...")
                self._current_step = 'step3'
                self.resilience_manager.save_state(self._save_context_state())

                self._update_context_from_automl(automl_results)

            # Step 4: Generate comprehensive report with integrated PDF generation
            if self._current_step in ['step3', 'step4']:
                print("Step 4: Generating final report with PDF...")
                self._current_step = 'step4'
                self.resilience_manager.save_state(self._save_context_state())

                report_generator.generate_report(
                    context=self.context,
                    vectorstore=vectorstore,
                    knowledge_graph=knowledge_graph,
                    config=self.config
                )

            # Save results for caching
            with open(results_json_path, 'w', encoding='utf-8') as f:
                json.dump(self.context.artifact_paths, f, indent=4)
            print(f"Saved run results to {results_json_path} for future use.")

            # Clean up checkpoint files after successful completion
            self._cleanup_checkpoints()

            print("MCP pipeline completed successfully!")

            # Print final summary
            self._print_final_summary()

            return self.context.artifact_paths

        except Exception as e:
            print(f"MCP pipeline failed: {e}")
            import traceback
            traceback.print_exc()

            # Save state for potential recovery
            self.resilience_manager.save_state(self._save_context_state())
            print("State saved for possible resumption")

            return {"error": str(e), "checkpoint_saved": True}

    def _update_context_from_automl(self, automl_results: dict):
        """Robust update of context with AutoML results."""
        print("Updating MCP with AutoML results...")

        # Safely get best model name
        self.context.best_model_name = automl_results.get("best_model_name", "Unknown Model")

        # Safely get SHAP data
        self.context.shap_data = automl_results.get("shap_data", {})

        # Initialize performance metrics with safe defaults
        performance_metrics = {
            'roc_auc': 0.0,
            'accuracy': 0.0,
            'precision': 0.0,
            'recall': 0.0,
            'f1': 0.0
        }

        # Get primary score
        primary_score = automl_results.get("score_val", 0.0)
        problem_type = automl_results.get("problem_type", "binary")

        # Set appropriate primary metric
        if problem_type == "binary":
            performance_metrics["roc_auc"] = primary_score
        else:
            performance_metrics["accuracy"] = primary_score

        # Parse classification report if available
        cr_path = automl_results.get("classification_report_path")
        if cr_path and os.path.exists(cr_path):
            try:
                cr_df = pd.read_csv(cr_path, index_col=0)

                # Enhanced metric extraction
                metrics_to_extract = ['precision', 'recall', 'f1-score', 'accuracy', 'roc_auc', 'auc']

                for metric in metrics_to_extract:
                    # Check rows
                    for index_name in cr_df.index:
                        if metric in index_name.lower():
                            value = cr_df.loc[index_name].iloc[0] if hasattr(cr_df.loc[index_name], 'iloc') else \
                            cr_df.loc[index_name]
                            if pd.notna(value):
                                performance_metrics[metric.replace('-', '_')] = float(value)
                            break

                    # Check columns
                    for col_name in cr_df.columns:
                        if metric in col_name.lower():
                            if 'accuracy' in cr_df.index:
                                value = cr_df.loc['accuracy', col_name]
                                if pd.notna(value):
                                    performance_metrics[metric.replace('-', '_')] = float(value)
                            break

                # Special handling for binary classification positive class
                if problem_type == "binary":
                    pos_class_keys = ['1', '1.0', 'true', 'positive']
                    for key in pos_class_keys:
                        if key in cr_df.index:
                            row = cr_df.loc[key]
                            for metric in ['precision', 'recall', 'f1-score']:
                                if metric in cr_df.columns and pd.notna(row.get(metric)):
                                    performance_metrics[metric.replace('-', '_')] = float(row[metric])
                            break

            except Exception as e:
                print(f"Warning: Could not parse classification report: {e}")

        # Update context with validated metrics
        self.context.performance = ModelPerformance(**performance_metrics)

        # Update artifact paths with validation
        artifact_mapping = {
            "classification_report": "classification_report_path",
            "feature_importance": "feature_importance_path",
            "feature_importance_plot": "feature_importance_plot",
            "confusion_matrix": "confusion_matrix_path",
            "roc_curve": "roc_curve_path",
            "precision_recall": "precision_recall_path",
            "shap_summary_path": "shap_summary_path"
        }

        for context_key, results_key in artifact_mapping.items():
            path = automl_results.get(results_key)
            if path and os.path.exists(path):
                self.context.artifact_paths[context_key] = path

        # Add additional metadata
        self.context.artifact_paths.update({
            "final_report_txt": os.path.join(self.context.output_dir, "final_report.txt"),
            "best_model_name": self.context.best_model_name,
            "score_val": primary_score,
            "all_test_scores": automl_results.get("all_test_scores", {})
        })

        print(
            f"Context updated with model: {self.context.best_model_name}, ROC-AUC: {performance_metrics['roc_auc']:.4f}")

    def _safe_float_convert(self, value):
        """Safely converts values to float, handling edge cases."""
        try:
            if value is None or (isinstance(value, float) and np.isnan(value)):
                return 0.0
            return float(value)
        except (ValueError, TypeError):
            return 0.0

    def _print_final_summary(self):
        """Print a comprehensive summary of the pipeline results."""
        print("\n" + "=" * 80)
        print("CREDIT RISK MODEL ASSESSMENT COMPLETED")
        print("=" * 80)

        # Model Performance Summary
        print(f"\nMODEL PERFORMANCE SUMMARY:")
        print(f"   Model: {self.context.best_model_name}")
        print(f"   ROC-AUC: {self.context.performance.roc_auc:.4f}")
        print(f"   Accuracy: {self.context.performance.accuracy:.4f}")
        print(f"   Precision: {self.context.performance.precision:.4f}")
        print(f"   Recall: {self.context.performance.recall:.4f}")
        print(f"   F1-Score: {self.context.performance.f1:.4f}")

        # Performance Classification
        roc_auc = self.context.performance.roc_auc
        if roc_auc >= 0.90:
            classification = "EXCELLENT"
            recommendation = "APPROVED FOR PRODUCTION"
        elif roc_auc >= 0.80:
            classification = "GOOD"
            recommendation = "APPROVED WITH MONITORING"
        elif roc_auc >= 0.70:
            classification = "ACCEPTABLE"
            recommendation = "CONDITIONAL APPROVAL"
        else:
            classification = "INSUFFICIENT"
            recommendation = "REJECTED - REDEVELOPMENT REQUIRED"

        print(f"\nPERFORMANCE CLASSIFICATION: {classification}")
        print(f"DEPLOYMENT RECOMMENDATION: {recommendation}")

        # Available Artifacts
        print(f"\nGENERATED ARTIFACTS:")
        available_artifacts = []

        artifact_descriptions = {
            'final_pdf_report': 'Professional PDF Report',
            'final_report_txt': 'Markdown Report',
            'roc_curve': 'ROC Curve Analysis',
            'confusion_matrix': 'Confusion Matrix',
            'shap_summary_path': 'SHAP Feature Importance',
            'feature_importance_plot': 'Feature Importance Plot',
            'precision_recall': 'Precision-Recall Curve',
            'knowledge_graph_viz': 'Knowledge Graph Visualization',
            'classification_report': 'Classification Report'
        }

        for key, description in artifact_descriptions.items():
            path = self.context.artifact_paths.get(key)
            if path and os.path.exists(path):
                print(f"   ✅ {description}: {path}")
            else:
                print(f"   ❌ {description}: Not available")

        # Key Risk Drivers
        top_features = self.context.shap_data.get('top_features', [])
        if top_features:
            print(f"\nTOP RISK DRIVERS:")
            for i, feature in enumerate(top_features[:5], 1):
                feature_name = feature.get('feature', f'Feature_{i}')
                importance = feature.get('importance', 0.0)
                print(f"   {i}. {feature_name}: {importance:.4f}")

        print(f"\nAll results saved to: {self.context.output_dir}")
        print("=" * 80)

        # Final recommendation box
        print(f"\n{'=' * 50}")
        print(f"EXECUTIVE SUMMARY FOR RISK COMMITTEE")
        print(f"{'=' * 50}")
        print(f"Model: {self.context.best_model_name}")
        print(f"Performance: {roc_auc:.4f} ROC-AUC ({classification})")
        print(f"Recommendation: {recommendation}")
        if self.context.artifact_paths.get('final_pdf_report'):
            print(f"Executive Report: {self.context.artifact_paths['final_pdf_report']}")
        print(f"{'=' * 50}")
# agents/mcp.py
"""
Model Context Protocol (MCP) - Core Data Structures
==================================================

This module defines the core data structures that act as a "passport"
traveling through the AI pipeline, accumulating data and results at each step.
"""

from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
import uuid


class ModelPerformance(BaseModel):
    """A Pydantic model to store model performance metrics."""
    roc_auc: Optional[float] = None
    accuracy: Optional[float] = None
    precision: Optional[float] = None
    recall: Optional[float] = None
    f1: Optional[float] = None

    def __str__(self) -> str:
        """String representation of performance metrics."""
        metrics = []
        if self.roc_auc is not None:
            metrics.append(f"ROC-AUC: {self.roc_auc:.4f}")
        if self.accuracy is not None:
            metrics.append(f"Accuracy: {self.accuracy:.4f}")
        if self.precision is not None:
            metrics.append(f"Precision: {self.precision:.4f}")
        if self.recall is not None:
            metrics.append(f"Recall: {self.recall:.4f}")
        if self.f1 is not None:
            metrics.append(f"F1: {self.f1:.4f}")

        return " | ".join(metrics) if metrics else "No metrics available"


class ModelContext(BaseModel):
    """
    The Model Context Protocol (MCP) object.
    This acts as a structured "passport" that travels through the AI pipeline,
    accumulating data and results at each step.
    """
    # Core identifiers
    run_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    dataset_path: str
    target_column: str
    output_dir: str

    # Populated during the pipeline
    best_model_name: Optional[str] = None
    performance: ModelPerformance = Field(default_factory=ModelPerformance)
    feature_importance: List[Dict[str, Any]] = Field(default_factory=list)
    shap_data: Optional[Dict[str, Any]] = None

    # Paths to generated artifacts for the dashboard
    artifact_paths: Dict[str, Optional[str]] = Field(default_factory=dict)

    # Final generated report
    final_report_text: Optional[str] = None

    def __str__(self) -> str:
        """String representation of the model context."""
        return f"ModelContext(run_id={self.run_id}, model={self.best_model_name}, {self.performance})"

    def get_performance_summary(self) -> Dict[str, Any]:
        """Get a summary of model performance for reporting."""
        return {
            "model_name": self.best_model_name or "Unknown",
            "run_id": self.run_id,
            "performance": self.performance.model_dump() if self.performance else {},
            "artifact_count": len([v for v in self.artifact_paths.values() if v is not None])
        }

    def update_artifact_path(self, artifact_type: str, path: str) -> None:
        """Safely update an artifact path."""
        if path and isinstance(path, str):
            self.artifact_paths[artifact_type] = path

    def get_artifact_path(self, artifact_type: str) -> Optional[str]:
        """Safely get an artifact path."""
        return self.artifact_paths.get(artifact_type)

    class Config:
        """Pydantic configuration."""
        arbitrary_types_allowed = True
        extra = "allow"  # Allow additional fields during pipeline execution